
import json


def CarregarBD(fnome):
    f=open(fnome, encoding='utf-8')
    bd = json.load(f)
    id=1
    for fil in bd:
        fil['id']= id
        id= id + 1
    return bd




def GuardarBD(bd, fnome):
    if not fnome.endswith('.json'):
        fnome += ".json"

    f=open(fnome, "w", encoding='utf-8')
    json.dump(bd, f)
    return




def InserirFilme(bd, valor):   
    novofil={}
    inf=valor
    novofil['title']= inf[0]
    novofil['year']= inf[1]
    novofil['cast']= inf[2]
    novofil['genres']= inf[3]
    novofil['id']=bd[-1]['id'] + 1
    bd.append(novofil)
    return bd




def ConsultarFilmeID(bd, valor):
    for fil in bd:
        if type(valor)==str and valor.isnumeric():   
            valor=int(valor)
        if fil['id']== valor:
            return fil
    



def consultarFilmeTitle(bd, valor):
    valorUpper= valor.upper()
    encontrados=[]
    for fil in bd:
        tituloUpper = fil['title'].upper()
        if valorUpper in tituloUpper:
            encontrados.append(fil)
    return encontrados




def ListarTitle(bd):
    return sorted(bd, key = lambda f: f['title'].lower())




def ListarGenres(bd, valor):    
    procurados=[]
    valorUpper= valor.upper()    
    for fil in bd:
        generosUpper=[]
        for g in fil['genres']:
            generosUpper.append(g.upper())
        if  valorUpper in generosUpper:
            procurados.append(fil)
    return procurados       

                
          

def ListarAtor(bd, valor):
    procurados=[]
    valorUpper= valor.upper() 
    for fil in bd:
        atoresUpper=[]
        for a in fil['cast']:
            atoresUpper.append(a.upper())
        i=0    
        for i in range(len(atoresUpper)):
            if  valorUpper in atoresUpper[i]:     
                procurados.append(fil) 
            i+=1              
    return procurados  

 


def Contador(bd):
    contador=0
    for fil in bd:
        contador= contador + 1
    return contador




def DistribGenero(bd):
    distribuicao={}
    for fil in bd:
        for genero in fil['genres']:
            if genero in distribuicao.keys():
                distribuicao[genero]= distribuicao[genero] +1
            else:
                distribuicao[genero]= 1
    return distribuicao




import matplotlib.pyplot as plt

def plotDistribPorGenero(bd):
    distribuicao=DistribGenero(bd)
 
    x = list(range(1,len(distribuicao.keys())+1))
    y = list(distribuicao.values())

    cursos = list(distribuicao.keys())

    plt.bar(x, y, tick_label = cursos,
            width = 0.8, color = ['blue'])

    plt.xlabel('Géneros')
    plt.ylabel('Nº Filmes')
    plt.title('Distribuição por Géneros')
    plt.xticks(rotation=45)

    plt.show()




def DistribAtor(bd):
    distribuicao={}
    for fil in bd:
        for ator in fil['cast']:
            if ator in distribuicao.keys():
                distribuicao[ator]= distribuicao[ator] +1
            else:
                distribuicao[ator]= 1  
    distribuicaoOrd = sorted(distribuicao.items(), key=lambda x: (-x[1], x[0]))
    return distribuicaoOrd




def Top10Atores(bd):
    listaOrd=DistribAtor(bd)
    listaAtores=[]
    for i in range(0,10):
        listaAtores.append(listaOrd[i])
    return listaAtores




import matplotlib.pyplot as plt

def plotDistribPorAtor(bd):
    distribuicao=Top10Atores(bd)
    listaX=[]
    listaY=[]
    for i in range(len(distribuicao)):
        listaX.append(distribuicao[i][0])
        listaY.append(distribuicao[i][1])

    x = listaX
    y = listaY
    
    plt.bar(x, y, tick_label = x,
            width = 0.8, color = ['green'])

    plt.xlabel('Atores')
    plt.ylabel('Nº Filmes')
    plt.title('Distribuição Top 10')
    plt.xticks(rotation=45)


    plt.show()

def ListaGeneros(bd):
    generos=[]
    for fil in bd:
        for gen in fil['genres']:
            if gen not in generos:
                generos.append(gen)
    return generos



# INTERFACE GRÁFICA


import FreeSimpleGUI as sg

BDFilmes=None
tipos=[("JSON (*.json)", "*.json")]
sg.theme('DarkBlue3')

menu_list_column = [
    [sg.Button("Carregar BD", size=(15, 2), font=("Baskerville", 14) ), sg.Button("Gravar BD", size=(15, 2), font=("Baskerville", 14)), sg.Button("Inserir registo", size=(15, 2), font=("Baskerville", 14)), sg.Button("Consultar Filme", size=(15, 2), font=("Baskerville", 14))],
    [sg.Button("Listagem", size=(15, 2), font=("Baskerville", 14)), sg.Button("Distribuição", size=(15, 2), font=("Baskerville", 14)), sg.Button("Contagem", size=(15, 2), font=("Baskerville", 14)), sg.Button("Sair", size=(15, 2), font=("Baskerville", 14))]
]

cabecalho = [
    [sg.Text("A MINHA CINEMATECA", size= (60,1), expand_x= True, justification= "center", font=("Cambria", 32, "bold"))],
    [sg.Text("Bem vindo!", size= (60,1), expand_x= True, justification= "center", font=("Cambria", 20))],
    [sg.Text('_'*103, justification= "center", text_color = "DarkBlue", pad=(0, 15))]

]

data_viewer_column = [

    [sg.Text(size=(40, 1), font=("Cambria", 16), expand_x= True, justification= "center", key="-Dados-")]
]


layout = [
    cabecalho,
    menu_list_column,
    [sg.Text('_'*103, justification= "center", text_color = "DarkBlue", pad=(0, 5))],
    data_viewer_column
  
]

window = sg.Window("Cinemateca", layout, size=(750, 400))

stop = False
while not stop:
    event, values = window.read()
    if event == "Sair" or event == sg.WIN_CLOSED:
        stop = True
 

    elif event == "Carregar BD":  
        window["-Dados-"].update("A carregar a base de dados...")
        formLayout = [
            [
                sg.Text("Base de dados:", font=("Baskerville", 12), pad=(0, 30)), 
                sg.Input(key="-FICHEIRO-", readonly=True, enable_events=True),
                sg.FileBrowse(file_types=tipos, size=(8,1), font=("Baskerville", 12)),
                sg.Button(key="-CARREGAR-", button_text="Carregar", size=(12,1), disabled=True, font=("Baskerville", 12))
            ]
        ]

        wform = sg.Window('Carregamento da base de dados',formLayout, size=(650,100))
        stopform=False
        while not stopform:
            inputEvent, inputValues = wform.read()
            if inputEvent == sg.WIN_CLOSED:
                window["-Dados-"].update("")
                stopform=True
            elif inputEvent=='-FICHEIRO-':
                wform["-CARREGAR-"].update(disabled=False)
            elif inputEvent == "-CARREGAR-":
                if inputValues['Browse']:
                    BDFilmes= CarregarBD(inputValues['Browse'])
                    stopform=True
                    window["-Dados-"].update("Base de dados carregada com sucesso!")
                    wform.close()

    elif event == "Gravar BD":  
        if not BDFilmes:
            window["-Dados-"].update("Primeiro carregue a base de dados!")
        else:
            window["-Dados-"].update("A gravar a base de dados...")
            formLayout = [
                [
                    sg.Text("Nome do ficheiro:", font=("Baskerville", 12), pad=(10, 30)),
                    sg.Input(size=(40,1), enable_events=True, key="-FICHEIRO-"),
                    sg.Button("Gravar", key='-GRA-', size=(10,1), disabled=True, font=("Baskerville", 12))
                ]
            ]
            wform = sg.Window('Gravar base de dados', formLayout, size=(600,100))
            stopform=False
            while not stopform:
                inputEvent, inputValues = wform.read()
                if inputEvent == sg.WIN_CLOSED:
                    window["-Dados-"].update("")
                    stopform=True
            
                elif inputEvent=='-FICHEIRO-':
                    wform['-GRA-'].update(disabled=False)

                elif inputEvent == '-GRA-':
                    if inputValues['-FICHEIRO-']:
                        GuardarBD(BDFilmes, inputValues['-FICHEIRO-'] )
                        window["-Dados-"].update("Base de dados gravada com sucesso!")
                        stopform=True
                        wform.close()
               


    elif event == "Inserir registo":  
        if not BDFilmes:
            window["-Dados-"].update("Primeiro carregue a base de dados!")
        else:    
            window["-Dados-"].update("A inserir um registo...")
            formLayout = [
            [sg.Text('Título:', size=(10, 1), font=("Baskerville", 12), justification= "center"), sg.InputText(key='-TIT-', enable_events=True, size=(65, 1))],
            [sg.Text('Ano:', size=(10, 1), font=("Baskerville", 12), justification= "center"), sg.InputText(key='-ANO-', enable_events=True,size=(65, 1))],
            [sg.Text('Elenco:', size=(10, 1), font=("Baskerville", 12), justification= "center"), sg.InputText(key='-ELE-',enable_events=True, size=(65, 1))],
            [sg.Text('Géneros:', size=(10, 1), font=("Baskerville", 12), justification= "center"), sg.InputText(key='-GEN-',enable_events=True, size=(65, 1))],
            [sg.Text('*Atenção: nos campos Elenco e Géneros separe o input por vírgula!*', font=("Baskerville", 10), pad=((0,45),(10,0)), expand_x= True, enable_events=True, justification= "right")],
            [sg.Button('Inserir', size=(10,1), disabled=True, key='-INS-', font=("Baskerville", 12), pad=((470,0),(20,0)))]
            ]

            wform = sg.Window('Inserção de um registo', formLayout,  size=(600,200))
            stopform=False
            AnoValido=False
            while not stopform:
                inputEvent, inputValues = wform.read()
                if inputEvent == sg.WIN_CLOSED:
                    window["-Dados-"].update("")
                    stopform=True
                elif inputEvent == '-TIT-' or inputEvent=='-ANO-' or inputEvent=='-ELE-' or inputEvent=='-GEN-':
                    if inputEvent=='-ANO-':
                        if inputValues['-ANO-'].isnumeric():
                            AnoValido=True
                            wform['-ANO-'].update(text_color='Black')
                        else:
                            wform['-ANO-'].update(text_color='Red')
                            AnoValido=False

                    if inputValues['-TIT-'] and inputValues['-ANO-'] and inputValues['-ELE-'] and inputValues['-GEN-'] and AnoValido:
                        wform['-INS-'].update(disabled=False)
                    else:
                        wform['-INS-'].update(disabled=True)
                    
                elif inputEvent== '-INS-':
                    if inputValues['-TIT-'] and inputValues['-ANO-'] and inputValues['-ELE-'] and inputValues['-GEN-']:
                        atores=[x.strip() for x in inputValues['-ELE-'].split(",")]
                        generos=[x.strip() for x in inputValues['-GEN-'].split(",")]
                        InserirFilme(BDFilmes, [inputValues['-TIT-'], int(inputValues['-ANO-']), atores, generos])
                        window["-Dados-"].update("Filme inserido com sucesso!")
                        wform.close()
               

                                                     
    elif event == "Consultar Filme":  
        if not BDFilmes:
            window["-Dados-"].update("Primeiro carregue a base de dados!")
        else:
            window["-Dados-"].update("A consultar filme...")
            resultados=[]
            formLayout = [[sg.Text('Quer procurar pelo ID ou pelo título do filme?', font=("Baskerville", 12))],
                [sg.Radio("ID", "OPCAO", default=False, key="-OPC1-", font=("Baskerville", 12)), sg.Radio("Título", "OPCAO", default=True, key="-OPC2-", font=("Baskerville", 12))],
                [sg.InputText(key='-CON-', size=(58,0)), sg.Button('Procurar',  size=(10,1), font=("Baskerville", 12), pad=((9,0),(5,10)))],
                [sg.Listbox(values= resultados,size=(81,10), horizontal_scroll=True, key="-RES-")]]

            wform = sg.Window('Consulta de filme', formLayout, size=(550,300))
            stopForm = False
            while not stopForm:
                resultados=[]
                inputEvent, inputValues = wform.read()
                if inputEvent == sg.WIN_CLOSED:
                    window["-Dados-"].update("")
                    stopForm=True
                else:
                    if inputEvent== "Procurar":
                        if inputValues['-CON-']:
                            if inputValues['-OPC1-']:
                                res=ConsultarFilmeID(BDFilmes, inputValues['-CON-'])
                                if res:
                                    resultados.append(res)
                                    window["-Dados-"].update("Filme consultado com sucesso!")
                                else: 
                                    resultados.append("O filme que procurou não existe!")
                                wform.find_element('-RES-').Update(values=resultados)

                            else:
                                res=consultarFilmeTitle(BDFilmes, inputValues['-CON-'])
                                if res:
                                    resultados.extend(res)
                                    window["-Dados-"].update("Filme consultado com sucesso!")
                                else: 
                                    resultados.append("O filme que procurou não existe!")
                                wform.find_element('-RES-').Update(values=resultados)
                    else:
                        window["-Dados-"].update("")       
                  
    elif event == "Listagem":  
        if not BDFilmes:
            window["-Dados-"].update("Primeiro carregue a base de dados!")
        else:
            window["-Dados-"].update("A listar filmes...")
            generos=ListaGeneros(BDFilmes)
            formLayout = [
                [sg.Text("Selecione o parâmetro pelo qual pretende listar:", pad=((0,0),(5,10)), font=("Baskerville", 12))],
                [sg.Radio("Ordem alfabética", "OPCAO", font=("Baskerville", 12), default=True, enable_events=True, key="-OPC1-"), sg.Radio("Género", "OPCAO",  font=("Baskerville", 12), default=False, enable_events=True, key="-OPC2-"), sg.Radio("Ator", "OPCAO",  font=("Baskerville", 12), default=False, enable_events=True, key="-OPC3-"), sg.Button("Listar", size=(10,1), font=("Baskerville", 12), pad=((10,0),(5,10)))],
                [sg.Combo(generos, default_value= generos[0], visible=False, key="-GEN-"), sg.InputText(key="-ATO-", visible=False, expand_x=True)],
                [sg.Listbox(values= resultados,size=(80,10), pad=((0,0),(15,10)), horizontal_scroll=True, key="-RES-")]

            ]
            wform = sg.Window('Listagem', formLayout, size=(600,300))
            stopForm = False
            while not stopForm:
                resultados=[]
                inputEvent, inputValues = wform.read()
                if inputEvent == sg.WIN_CLOSED:
                    stopForm=True
                else:
                    if inputEvent=='-OPC1-':
                        wform['-GEN-'].update(visible=False)
                        wform['-ATO-'].update(visible=False)

                    if inputEvent=='-OPC2-':
                        wform['-GEN-'].update(visible=True)
                        wform['-ATO-'].update(visible=False)

                    if inputEvent=='-OPC3-':
                        wform['-GEN-'].update(visible=False)
                        wform['-ATO-'].update(visible=True)

                    if inputEvent== "Listar":
                        if inputValues['-OPC1-']:
                            res=ListarTitle(BDFilmes)
                            resultados.extend(res)
                            wform.find_element('-RES-').Update(values=resultados)

                        elif inputValues['-OPC2-']:
                            res= ListarGenres(BDFilmes, inputValues['-GEN-'])
                            resultados.extend(res)
                            wform.find_element('-RES-').Update(values=resultados)

                        elif inputValues['-OPC3-']:
                            res= ListarAtor(BDFilmes, inputValues['-ATO-'])
                            resultados.extend(res)
                            wform.find_element('-RES-').Update(values=resultados)
                   
                    window["-Dados-"].update("Listagem realizada com sucesso!")
            window["-Dados-"].update("")

    elif event == "Contagem":
        if not BDFilmes:
            window["-Dados-"].update("Primeiro carregue a base de dados!")
        else:   
            res=str(Contador(BDFilmes))
            window["-Dados-"].update("Existem " + res + " filmes na cinemateca!")



    elif event == "Distribuição":  
        if not BDFilmes:
            window["-Dados-"].update("Primeiro carregue a base de dados!")
        else:
            window["-Dados-"].update("A produzir dados estatísticos...")
            formLayout = [
                [sg.Button("Por género", size=(14, 2), font=("Baskerville", 12), pad=((100,0),(5,0))), sg.Button("TOP 10 Atores", font=("Baskerville", 12), size=(14, 2),pad=((100,0),(5,0)))]
                ]
            wform = sg.Window('Dados estatísticos', formLayout, size=(600,70))
            stopForm = False
            while not stopForm:
                inputEvent, inputValues = wform.read()
                if inputEvent == sg.WIN_CLOSED:
                    stopForm=True
                    window["-Dados-"].update("")
                else:
                    if inputEvent== "Por género":
                        plotDistribPorGenero(BDFilmes)
                               

                    else:
                        plotDistribPorAtor(BDFilmes)
                            
                    window["-Dados-"].update("Dados estatísticos calculados com sucesso!")

              

    else:
        window["-Dados-"].update("Erro: evento desconhecido :: " + inputEvent)

window.close()








