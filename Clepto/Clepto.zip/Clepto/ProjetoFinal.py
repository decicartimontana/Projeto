import json
from datetime import datetime
import matplotlib.pyplot as plt
import FreeSimpleGUI as sg
import matplotlib.image as mpimg
import tkinter as tk
import tkinter as ttk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from collections import Counter
from tkinter import Canvas
import pandas as pd
import os

cor_clara = '#EFDCF9'
cor_escura = '#7954A1'
cor_mais_clara = '#EFDCF9'
cor_mais_escura = '#8740A4'
cor_complementar = "#4C2A85"

#Função Janela Erro
def janelaErro(tipoerro):
    layout=[
        [sg.Text(tipoerro,background_color=cor_clara,font = ("Cooper Hewitt",12), text_color=cor_escura)], 
        [sg.Button("Ok", button_color=(cor_clara,cor_escura),font = ('Cooper Hewitt',12))]
        ]
    window= sg.Window(title="Janela Erro",background_color=cor_clara, default_element_size=(15,1)).Layout(layout)

    stop=False  
    while not stop:
        evento, valor = window.read()
        if evento == "Ok" or evento == sg.WIN_CLOSED:
            stop = True
    window.close()

#Função Carregar BD
def carregarBD(dataset):
    if '.json' in  dataset:   
        f=open(dataset, encoding="utf-8")
        info = json.load(f)
        f.close()
        return info
    else :
        return 
    
#Função Acrescentar dataset 
def acrescDataset(dataset, bd):
    f2= open(dataset, encoding="utf-8")
    dataset=json.load(f2)
    for i in dataset['tarefas']:
        if i not in bd['tarefas']:
            bd['tarefas'].append(i)
    f2.close()
    return bd

#Função Gravar BD
def gravarBD(nome,dataset):
    ficheiro = open(nome,'w',encoding='utf-8')
    json.dump(dataset,ficheiro,ensure_ascii=False,indent=2)
    ficheiro.close()

#Funções Consultar
def consultartitulo(n, dataset):
    return [tarefa for tarefa in dataset["tarefas"] if "titulo" in tarefa and tarefa["titulo"] == n]

def consultardatavencimento(n, dataset):
    return [tarefa for tarefa in dataset["tarefas"] if "data_vencimento" in tarefa and tarefa["data_vencimento"] == n]

def consultarPrioridade(prioridade, dataset):
    tarefas_encontradas = []
    for tarefa in dataset["tarefas"]:
        if "prioridade" in tarefa.keys() and tarefa["prioridade"] == prioridade:
            tarefas_encontradas.append(tarefa)
    return tarefas_encontradas

def consultarEstado(n, dataset):
    tarefasencontradas = []
    for tarefa in dataset["tarefas"]:
        if "concluida" in tarefa.keys():
            if n == "Concluído" or n=="Concluídas":
                if tarefa["concluida"] == True:
                    tarefasencontradas.append(tarefa)
            elif n == "Não Concluído" or n== "Não Concluídas":
                if tarefa["concluida"] == False:
                    tarefasencontradas.append(tarefa)
    return tarefasencontradas

def consultarCategoria(n,dataset):
    tarefascategoria=[]
    for tarefa in dataset["tarefas"]:
        if "categoria" in tarefa.keys():
            if tarefa["categoria"].lower()==n.lower():
                tarefascategoria.append(tarefa)
    return tarefascategoria

#Função Criar Tarefa
def criar_tarefa(dataset, novatarefa):
    dataset['tarefas'].append(novatarefa)
    return dataset

#Função Eliminar tarefa
def eliminarTarefa(id_tarefa, BD):
    for index, tarefa in enumerate(BD["tarefas"]):
        if tarefa["id"] == id_tarefa:
            titulo_tarefa = tarefa["titulo"]
            BD["tarefas"].pop(index)
            
            # Renumerar os IDs restantes
            for i, tarefa_remanescente in enumerate(BD["tarefas"]):
                tarefa_remanescente["id"] = i + 1
            
            return True  # Indica que a tarefa foi eliminada com sucesso

    return False  # Indica que a tarefa com o ID fornecido não foi encontrada no BD

#Função Alterar Tarefa
def alterarDetalhesTarefa(id_tarefa, novo_titulo, nova_descricao, nova_prioridade, nova_categoria, nova_conc, nova_data_vencimento, BD):
    # Encontrar a tarefa no banco de dados pelo ID
    for tarefa in BD["tarefas"]:
        if tarefa["id"] == id_tarefa:
            # Atualizar os detalhes da tarefa
            tarefa["titulo"] = novo_titulo
            tarefa["descricao"] = nova_descricao
            tarefa["prioridade"] = nova_prioridade
            tarefa["categoria"] = nova_categoria
            tarefa["concluida"] = nova_conc.lower() == 'true' 
            tarefa["data_vencimento"] = nova_data_vencimento

            return True  # Indica que a tarefa foi alterada com sucesso

    return False  # Indica que a tarefa com o ID fornecido não foi encontrada no BD

#Função Listar
def listarcategoriae(dataset):
    categorias = []
    for tarefa in dataset['tarefas']:
        if 'categoria' in tarefa:
            categorias.append(tarefa['categoria'])
    return categorias

def listacategoria(dataset):
    categorias = listarcategoriae(dataset)
    categorias_unicas = set(categoria.lower().strip() for categoria in categorias)
    return sorted(categorias_unicas)

def listar_categoria(dataset, categoria):
    res = []
    for tarefa in dataset['tarefas']:
        if tarefa['categoria'].lower() == categoria:
            res.append(tarefa['titulo'])

    return res

def listar_prioridade(dataset, prioridade):
    res = []
    for tarefa in dataset['tarefas']:
        if tarefa['prioridade'] == prioridade:
            res.append(tarefa['titulo'])

    return res

def listapri(BD):
    lista_de_tarefas = BD.get('tarefas', [])

    def chave_de_ordenacao(tarefa):
        prioridades = {'Urgente': 0, 'Alta': 1, 'Média': 2, 'Baixa': 3}
        return prioridades.get(tarefa['prioridade'], float('inf'))

    tarefas_ordenadas = sorted(lista_de_tarefas, key=chave_de_ordenacao)

    res = [f"{tarefa['prioridade']} | {tarefa['titulo']}" for tarefa in tarefas_ordenadas]

    return res

def listadata(BD):
    lista_de_tarefas = BD.get('tarefas', [])
    def chave_de_ordenacao(tarefa):
        data_vencimento = tarefa.get('data_vencimento', '')
        return data_vencimento

    tarefas_ordenadas = sorted(lista_de_tarefas, key=chave_de_ordenacao)

    res = [f"{tarefa['data_vencimento']} | {tarefa['titulo']}" for tarefa in tarefas_ordenadas]

    return res

def listaprioridades(dataset):
    lista = []
    for tarefa in dataset['tarefas']:
        lista.append(tarefa['prioridade'])
    return lista

def listar_estado(dataset, estado):
    res = []
    for tarefa in dataset['tarefas']:
        if tarefa['concluida'] == estado:
            res.append(tarefa['titulo'])

    return res

def listaestado(dataset):
    lista = []
    for tarefa in dataset['tarefas']:
        lista.append(tarefa['concluida'])
    return lista

def listatitulo(dataset):
    lista =[]
    for tarefa in dataset["tarefas"]:
        if tarefa["titulo"] not in lista:
            lista.append(tarefa["titulo"])
    return lista

def listardatas(dataset):
    return [datetime.strptime(task["data_vencimento"], "%Y-%m-%d") for task in dataset["tarefas"]]

#Função Contagem
def contagem(dataset,criterio,nome):
    c = 0
    for tarefa in dataset['tarefas']:
        if tarefa[criterio] == nome:
            c = c+1
    return c

#Função Progresso das Tarefas (Relatório)
def calcular_progresso_tarefas(dataset):
    now = datetime.now()
    
    concluidas = sum(1 for task in dataset["tarefas"] if task["concluida"] and datetime.strptime(task["data_vencimento"], "%Y-%m-%d") <= now)
    pendentes = sum(1 for task in dataset["tarefas"] if not task["concluida"])
    atrasadas = sum(1 for task in dataset["tarefas"] if not task["concluida"] and datetime.strptime(task["data_vencimento"], "%Y-%m-%d") < now)


    return concluidas, pendentes, atrasadas

#Função Atualizar tarefas 
def atualizar_tarefa(dataset_path, tarefa_id, novos_dados):
    file = open(dataset_path, 'r', encoding='utf-8')
    dataset = json.load(file)
    file.close()

    for tarefa in dataset["tarefas"]:
        if tarefa["id"] == tarefa_id:
            for chave, valor in novos_dados.items():
                tarefa[chave] = valor

    file = open(dataset_path, 'w', encoding='utf-8')
    json.dump(dataset, file, ensure_ascii=False, indent=2)
    file.close()

#Função Obter tarefa por categoria 
def obter_tarefas_por_categoria(dataset_path, categoria):
    file = open(dataset_path, 'r', encoding='utf-8')
    dataset = json.load(file)
    file.close()

    tarefas_por_categoria = [tarefa for tarefa in dataset["tarefas"] if tarefa["categoria"] == categoria]
    return tarefas_por_categoria

#Função Organizar por Prioridade
def definir_prioridade(dataset_path, tarefa_id, nova_prioridade):
    file = open(dataset_path, 'r', encoding='utf-8')
    dataset = json.load(file)
    file.close()

    for tarefa in dataset["tarefas"]:
        if tarefa["id"] == tarefa_id:
            tarefa["prioridade"] = nova_prioridade

    file = open(dataset_path, 'w', encoding='utf-8')
    json.dump(dataset, file, ensure_ascii=False, indent=2)
    file.close()

def ordenar_tarefas_por_prioridade(dataset_path):
    file = open(dataset_path, 'r', encoding='utf-8')
    dataset = json.load(file)
    file.close()

    tarefas_ordenadas = sorted(dataset["tarefas"], key=lambda x: x["prioridade"])

    return tarefas_ordenadas

#Funções Relatório 
def gerar_relatorio_progresso(tarefas):
    data_atual = datetime.now()
    
    # Separar tarefas concluídas, pendentes (não concluídas e não atrasadas) e atrasadas
    tarefas_concluidas = [tarefa for tarefa in tarefas if tarefa["concluida"] ]
    tarefas_pendentes = [tarefa for tarefa in tarefas if not tarefa["concluida"] and datetime.strptime(tarefa["data_vencimento"], "%Y-%m-%d") > data_atual]
    tarefas_atrasadas = [tarefa for tarefa in tarefas if not tarefa["concluida"] and datetime.strptime(tarefa["data_vencimento"], "%Y-%m-%d") < data_atual]

    # Criar o relatório
    relatorio = [
        {"titulo": "Total de Tarefas", "quantidade": len(tarefas), "detalhes": tarefas},
        {"titulo": f"Tarefas Concluídas ({len(tarefas_concluidas)})", "detalhes": tarefas_concluidas},
        {"titulo": f"Tarefas Pendentes ({len(tarefas_pendentes)})", "detalhes": tarefas_pendentes},
        {"titulo": f"Tarefas Atrasadas ({len(tarefas_atrasadas)})", "detalhes": tarefas_atrasadas},
    ]

    return relatorio

def exibir_relatorio_escrito_com_progresso(tarefas):
    relatorio = gerar_relatorio_progresso(tarefas)
    janela_relatorio_escrito_com_progresso = tk.Toplevel()
    janela_relatorio_escrito_com_progresso.title("Relatório Geral de Tarefas com Progresso")

    texto_relatorio_com_progresso = tk.Text(janela_relatorio_escrito_com_progresso, wrap=tk.WORD)
    texto_relatorio_com_progresso.insert(tk.END, "Relatório Geral de Tarefas com Progresso:\n\n")

    for secao in relatorio:
        texto_relatorio_com_progresso.insert(tk.END, f"{secao['titulo']}:\n")
        for tarefa in secao['detalhes']:
            texto_relatorio_com_progresso.insert(tk.END, f"  - {tarefa['titulo']} ({tarefa['data_vencimento']})\n")
        texto_relatorio_com_progresso.insert(tk.END, "\n")

    texto_relatorio_com_progresso.pack()

#Interface
def interfacegrafica():
    BD = None
    Guardada = 0
    tipos=[("JSON (*.json)", "*.json")]
    cor_clara = '#EFDCF9'
    cor_escura = '#7954A1'

    Menu = [
        [sg.Push(background_color=cor_clara),
        sg.Button('Carregar BD', size=(25, 2), font=("Cooper Hewitt", 14), button_color=(cor_clara, cor_escura),
                tooltip='Clique para carregar uma base de dados'),
        sg.Button("Gravar BD", size=(25, 2), font=("Cooper Hewitt", 14), button_color=(cor_clara, cor_escura),
                tooltip='Clique para guardar a base de dados carregada'),
        sg.Button("Acrescentar Dataset", size=(25, 2), font=("Cooper Hewitt", 14), button_color=(cor_clara, cor_escura),
                tooltip='Clique para acrescentar um dataset'),
        sg.Button("Inserir Nova Tarefa", size=(25, 2), font=("Cooper Hewitt", 14), button_color=(cor_clara, cor_escura),
                tooltip='Clique para inserir uma nova tarefa na sua base de dados'),
        sg.Push(background_color=cor_clara)],
        [sg.Push(background_color=cor_clara),
        sg.Button('Consultar tarefa', size=(25, 2), font=("Cooper Hewitt", 14), button_color=(cor_clara, cor_escura),
                tooltip='Clique para consultar tarefa'),
        sg.Button("Listagem", size=(25, 2), font=("Cooper Hewitt", 14), button_color=(cor_clara, cor_escura),
                tooltip='Clique para listar as tarefas por data de vencimento, prioridade, categoria e conclusão'),
        sg.Button("Alterar tarefa", size=(25, 2), font=("Cooper Hewitt", 14), button_color=(cor_clara, cor_escura),
                tooltip='Clique para alterar uma tarefa'),
        sg.Button("Eliminar tarefa", size=(25, 2), font=("Cooper Hewitt", 14), button_color=(cor_clara, cor_escura),
                tooltip='Clique para eliminar uma tarefa da sua base de dados'),
        sg.Push(background_color=cor_clara)],
        [sg.Push(background_color=cor_clara),
        sg.Button('Relatórios', size=(25, 2), font=("Cooper Hewitt", 14), button_color=(cor_clara, cor_escura),
                tooltip='Clique para consultar os relatórios de progresso das tarefas'),
        sg.Button("Contagem", size=(25, 2), font=("Cooper Hewitt", 14), button_color=(cor_clara, cor_escura),
                tooltip='Clique para obter o número de tarefas na base de dados'),
        sg.Push(background_color=cor_clara)],
    ]



    cabecalho = [
        [sg.Text("Task Master", size=(35, 1), expand_x=True, justification="center", font=("Cambria", 32, "bold"),
                background_color=cor_clara, text_color=cor_escura)],
        [sg.Text("MENU", size=(35, 1), expand_x=True, justification="center", font=("Cambria", 20),
                background_color=cor_clara, text_color=cor_escura)],
        [sg.Push(background_color=cor_clara),
        sg.Text('  ' * 205, justification="center", background_color=cor_escura, pad=(0, 15)),
        sg.Push(background_color=cor_clara)]
    ]




    data = [
        [sg.Text(size=(45, 1), font=("Cambria", 16), expand_x=True, justification="center", key="-Dados-",
                background_color=cor_clara, text_color=cor_escura)]
    ]



    layout = [
        cabecalho,
        Menu,
        [sg.Push( background_color=cor_clara),sg.Text('  '*205, justification= "center", background_color=cor_escura, pad=(0, 15)), sg.Push( background_color=cor_clara)],
        [data, sg.Button("Help", size=(20, 1), font=("Cambria", 18), button_color=(cor_escura, cor_clara),tooltip='Clique para ajuda'), sg.Push(background_color=cor_clara), sg.Button("Sair", size=(20, 1), font=("Cooper Hewitt", 18), button_color=(cor_escura, cor_clara),
                tooltip='Clique para sair da aplicação')]
    
    ]


    window = sg.Window(title="Task Master", resizable=True, background_color=cor_clara).Layout(layout)


    stop = False

    while stop == False:

        eventos, valores = window.read()
        
        if eventos in [sg.WIN_CLOSED, 'Exit']:
            stop = True

        elif eventos == 'Sair':
            stop = True
            window.close()


        elif eventos == "Carregar BD":  
            window["-Dados-"].update("A carregar a base de dados...")
            formLayout = [
                [
                sg.Text("Base de dados:", font=("Cooper Hewitt", 12), pad=(0, 30), text_color=cor_clara, background_color=cor_escura),
                sg.InputText(key="-FICHEIRO-", readonly=True, enable_events=True, text_color=cor_escura),
                sg.FileBrowse(file_types=tipos, size=(8, 1), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)),
                sg.Button(key="-CARREGAR-", button_text="Carregar", size=(12, 1), disabled=True, font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)) 
                ]
            ]

            wform = sg.Window('Carregamento da base de dados',formLayout, size=(650,100), background_color=cor_clara)


            stopform = False
            while not stopform:
                inputEvent, inputValues = wform.read()
                if inputEvent == sg.WIN_CLOSED:
                    window["-Dados-"].update("")
                    stopform = True
                elif inputEvent == '-FICHEIRO-':
                    wform["-CARREGAR-"].update(disabled=False)
                elif inputEvent == "-CARREGAR-":
                    if inputValues['Browse']:
                        BD = carregarBD(inputValues['Browse'])
                        nome = inputValues['Browse']
                        stopform = True
                        window["-Dados-"].update("Base de dados carregada com sucesso!")
                        wform.close()

        elif eventos == "Gravar BD":
            window["-Dados-"].update("A gravar base de dados...")
            
            if BD == None:
                janelaErro ("Introduza primeiro uma base de dados!")
            
            else:
                Guardada = 1
                gravarBD(nome, BD)
                window["-Dados-"].update("Base de dados gravada!")
        


        elif eventos == "Acrescentar Dataset":
            window["-Dados-"].update('A acrescentar Dataset...')

            if BD == None:
                janelaErro ("Introduza primeiro uma base de dados!")
        
            elif Guardada == 0:
                janelaErro ("Guarde primeiro a base de dados!")

            else:
                formLayout2 = [
                    [
                    sg.Text("Base de dados:", font=("Cooper Hewitt", 12), pad=(0, 30), text_color=cor_clara, background_color=cor_escura),
                    sg.InputText(key="-FICHEIRO-", readonly=True, enable_events=True, text_color=cor_escura),
                    sg.FileBrowse(file_types=tipos, size=(8, 1), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)),
                    sg.Button(key="-CARREGAR-", button_text="Carregar", size=(12, 1), disabled=True, font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura))  
                    ]
                ]

                wform2 = sg.Window('Acrescentar base de dados',formLayout2, size=(650,100), background_color=cor_clara)

                stopform2 = False
                while not stopform2:
                    inputEvent2, inputValues2 = wform2.read()
                    if inputValues2 == sg.WINDOW_CLOSED:
                        window["-Dados-"].update("")
                        stopform2 = True
                    elif inputEvent2 == '-FICHEIRO-':
                        wform2["-CARREGAR-"].update(disabled=False)
                    elif inputEvent2 == "-CARREGAR-":
                        if inputValues2['Browse']:
                            BD = acrescDataset(inputValues2['Browse'],BD)
                            nome = inputValues2['Browse']
                            stopform2 = True
                            window["-Dados-"].update("Base de dados adicionada com sucesso!")
                            wform2.close()

        
        elif eventos == "Inserir Nova Tarefa":
            window["-Dados-"].update('A acrescentar nova tarefa...')

            if BD == None:
                janelaErro ("Introduza primeiro uma base de dados!")
        
            elif Guardada == 0:
                janelaErro ("Guarde primeiro a base de dados!")
            
            else:
                formLayout3 = [
                    [sg.Text('*Título:', size=(16, 1), expand_x=True, font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura),sg.InputText("", key='titulo')],
                    [sg.Text('*Descrição:', size=(16, 1), expand_x=True, font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura),sg.InputText("", key='descricao')],
                    [sg.Text('*Data de vencimento:', size=(16, 1), expand_x=True, font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura), sg.CalendarButton('Escolha a data', target='data_vencimento', key='calendario', format='%Y-%m-%d')],
                    [sg.InputText('', key='data_vencimento', background_color=cor_clara, text_color=cor_escura,pad=((480,0),(0,0)))], # Campo oculto para armazenar a data selecionada
                    [sg.Text('*Prioridade:', size=(10, 1), expand_x=True, font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura),sg.Combo(["Baixa", "Média", "Alta", "Urgente"], key="prioridade", font=("Cooper Hewitt", 12),background_color=cor_escura, text_color=cor_clara)],
                    [sg.Text('*Categoria:', size=(16, 1), expand_x=True, font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura),sg.InputText("", key='categoria')],
                    [sg.Text('*Estado:', size=(10, 1), expand_x=True, font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura),sg.Combo(["Concluída", "Não concluída"], key="concluida", font=("Cooper Hewitt", 12),background_color=cor_escura, text_color=cor_clara)],
                    [sg.Text ('* Indica um campo obrigatório', font=("Bid Shoulders Display", 12), background_color=cor_clara, text_color=cor_escura, expand_x= True, enable_events=True)],
                    [sg.Button ('Adicionar', button_color=(cor_clara,cor_escura),font = ("Big Shoulders Display",12))]
                
                ]
                wform3 = sg.Window('Inserir nova tarefa',formLayout3, background_color=cor_clara)
        
                stopform3 = False
                            
                while stopform3 == False:
                    inputEvent3, inputValues3 = wform3.read()

                                
                    if inputEvent3 in [sg.WIN_CLOSED, 'Exit']:
                        stopform3 = True
                                
                    elif inputEvent3 == 'Adicionar':
                        if (inputValues3['titulo'] == '') or (inputValues3['descricao'] == '') or (inputValues3['data_vencimento'] == '') or (inputValues3['prioridade'] == '') or (inputValues3['categoria'] == '') or (inputValues3['concluida'] == ''):
                            janelaErro('Preencha todos os campos obrigatorios (*)!')

                    
                        else:
                            concluida_value = True if inputValues3['concluida'] == 'Concluída' else False

                            novatarefa = {'id': len(BD['tarefas'])+1, 
                                        'titulo': inputValues3['titulo'], 
                                        'descricao': inputValues3['descricao'], 
                                        'data_vencimento': inputValues3['data_vencimento'], 
                                        'prioridade': inputValues3['prioridade'], 
                                        'categoria': inputValues3['categoria'],
                                        'concluida': concluida_value
                                        }
                            
                            
                            BD = criar_tarefa(BD, novatarefa)
                            window["-Dados-"].update('Tarefa adicionada com sucesso!')
                            wform3.close()   
        
        
        elif eventos == "Consultar tarefa":
            window["-Dados-"].update("A consultar tarefa...")

            if BD == None :
                janelaErro ("Introduza primeiro uma base de dados!")

            elif Guardada == 0:
                janelaErro ("Guarde primeiro a base de dados!")
            
            else:
                
                layout8 = [
                    [sg.Text ('Deseja consultar o tarefa por:', size= (45,1), expand_x= True, font=("Cambria", 15, "bold"),background_color=cor_clara,text_color=cor_escura)],
                    [sg.Button ('Prioridade', size=(12,1),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",12)),sg.Button ('Categoria', size=(12,1),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",12)),sg.Button ('Estado', size=(10,1),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",12)),sg.Button ('Título', size=(10,1),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",12)),sg.Button ('Data de Vencimento', size=(17,1),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",12)),sg.Button ('Retornar ao Menu',font=("Cooper Hewitt", 14), button_color= (cor_clara,cor_escura))],     
                ]
                
                window8 = sg.Window(title="Consultar Tarefa", resizable=True, background_color=cor_clara).Layout(layout8)
                stop8 = False
                
                while stop8 == False:
                    eventos8, valores8 = window8.read()
                    
                    if eventos8 in [sg.WIN_CLOSED, 'Exit'] or eventos8=='Retornar ao Menu':
                        stop8 = True
                        window8.close()
                    
                    elif eventos8 == 'Título':
                        window8.close()
                        resultados = []
                        
                        layout8 = [
                            [sg.Text('Título:', size=(14, 1), expand_x=True, font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura)],
                            [sg.Combo(values=listatitulo(BD), key='titulo', font=("Cooper Hewitt", 12),background_color=cor_escura, text_color=cor_clara)],
                            [sg.Button('OK', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12)),
                            sg.Button('Sair', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))],
                        ]
                        
                        window9 = sg.Window(title="Consultar tarefa pelo Título", resizable=True, background_color=cor_clara).Layout(layout8)
                        stop9 = False
                        
                        while not stop9:
                            eventos9, valores9 = window9.read()

                            if eventos9 in [sg.WIN_CLOSED, 'Exit']:
                                stop9 = True

                            elif eventos9 == 'OK':
                                resultados = []
                                tarefas_encontradas = consultartitulo(valores9['titulo'], BD)

                                if tarefas_encontradas:
                                    tarefas_info = [f"{tarefa['id']} : {tarefa['titulo']} : {tarefa['descricao']} : {tarefa['data_vencimento']} : {tarefa['prioridade']} : {tarefa['categoria']} : {tarefa['concluida']}" for tarefa in tarefas_encontradas]

                                    layout_titulo11 = [
                                        [sg.Text('Selecione a tarefa:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura)],
                                        [sg.Listbox(values=tarefas_info, size=(80, 10), key='-TAREFAS-', pad=((0, 0), (15, 10)), enable_events=True)],
                                        [sg.Button('Sair', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))]
                                    ]

                                    window_titulo11 = sg.Window('Selecionar Tarefa', layout_titulo11, grab_anywhere=False, finalize=True,
                                        background_color=cor_clara)

                                    stoptitulo11 = False

                                    while not stoptitulo11:
                                        eventtitulo11, valuestitulo11 = window_titulo11.read()

                                        if eventtitulo11 in (sg.WIN_CLOSED, 'Sair'):
                                            stoptitulo11 = True
                                            window_titulo11.close()

                                        elif eventtitulo11 == '-TAREFAS-':
                                            selected_index = valuestitulo11['-TAREFAS-'][0]

                                            if selected_index is not None:
                                                selected_index1 = selected_index.split(':')

                        # Agora você pode usar selected_tarefa para exibir os detalhes na nova janela
                                                detalhes_tarefa_layout = [
                                                    [sg.Text(f"Tarefa Selecionada:\n\nTítulo: {selected_index1[1]}\n"
                                                    f"Descrição: {selected_index1[2]}\n"
                                                    f"Data de Vencimento: {selected_index1[3]}\n"
                                                    f"Prioridade: {selected_index1[4]}\n"
                                                    f"Categoria: {selected_index1[5]}\n"
                                                    f"Concluída: {selected_index1[6]}", text_color=cor_escura,background_color=cor_clara)],
                                                    [sg.Button('Fechar', size=(10, 1), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura))]
                                                ]

                                                window_detalhes_tarefa = sg.Window('Detalhes Tarefa', detalhes_tarefa_layout, grab_anywhere=False,
                                                        finalize=True, background_color=cor_clara)

                                                stop_detalhes_tarefa = False

                                                while not stop_detalhes_tarefa:
                                                    event_detalhes_tarefa, values_detalhes_tarefa = window_detalhes_tarefa.read()

                                                    if event_detalhes_tarefa in (sg.WIN_CLOSED, 'Fechar'):
                                                        stop_detalhes_tarefa = True
                                                        window_detalhes_tarefa.close()

                            elif eventos9 == 'Sair':
                                stop9 = True

                        window9.close()


                    
                    elif eventos8 == 'Data de Vencimento':
                        window8.close()
                        resultados2 = []

                        layout_consulta_data_vencimento = [
                            [sg.Text('Data de Vencimento', size=(25, 1), expand_x=True, font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura),
                            sg.CalendarButton('Escolha a Data', target='-DATA-', font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)),
                            sg.InputText("", key='-DATA-', readonly=True, font=("Cooper Hewitt", 12))],
                            [sg.Button('OK', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12)),
                            sg.Button('Sair', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))],
                        ]

                        window10 = sg.Window(title="Consultar tarefa pela data de vencimento", resizable=True, background_color=cor_clara).Layout(layout_consulta_data_vencimento)
                        stop10 = False

                        while not stop10:
                            eventos10, valores10 = window10.read()

                            if eventos10 in [sg.WIN_CLOSED, 'Exit']:
                                stop10 = True

                            elif eventos10 == 'OK':
                                resultados2 = []
                                if '-DATA-' in valores10:
                                    data_selecionada = valores10['-DATA-'].split()[0]  # Pega apenas a parte da data
                                    tarefas_encontradas1 = consultardatavencimento(data_selecionada, BD)

                                    if tarefas_encontradas1:
                                        tarefas_info12 = [f"{tarefa['id']} : {tarefa['titulo']} : {tarefa['descricao']} : {tarefa['data_vencimento']} : {tarefa['prioridade']} : {tarefa['categoria']} : {tarefa['concluida']}" for tarefa in tarefas_encontradas1]

                                        layout_titulo12 = [
                                            [sg.Text('Selecione a tarefa:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura)],
                                            [sg.Listbox(values=tarefas_info12, size=(80, 10), key='-TAREFAS-', pad=((0, 0), (15, 10)), enable_events=True)],
                                            [sg.Button('Sair', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))]
                                        ]

                                        window_titulo12 = sg.Window('Selecionar Tarefa', layout_titulo12, grab_anywhere=False, finalize=True,
                                        background_color=cor_clara)

                                        stoptitulo12 = False

                                        while not stoptitulo12:
                                            eventtitulo12, valuestitulo12 = window_titulo12.read()

                                            if eventtitulo12 in (sg.WIN_CLOSED, 'Sair'):
                                                stoptitulo12 = True
                                                window_titulo12.close()

                                            elif eventtitulo12 == '-TAREFAS-':
                                                selected_index11 = valuestitulo12['-TAREFAS-'][0]

                                                if selected_index11 is not None:
                                                    selected_index12 = selected_index11.split(':')

                        # Agora você pode usar selected_tarefa para exibir os detalhes na nova janela
                                                    detalhes_tarefa_layout = [
                                                        [sg.Text(f"Tarefa Selecionada:\n\nTítulo: {selected_index12[1]}\n"
                                                        f"Descrição: {selected_index12[2]}\n"
                                                        f"Data de Vencimento: {selected_index12[3]}\n"
                                                        f"Prioridade: {selected_index12[4]}\n"
                                                        f"Categoria: {selected_index12[5]}\n"
                                                        f"Concluída: {selected_index12[6]}", text_color=cor_escura,background_color=cor_clara)],
                                                        [sg.Button('Fechar', size=(10, 1), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura))]
                                                    ]

                                                    window_detalhes_tarefa = sg.Window('Detalhes Tarefa', detalhes_tarefa_layout, grab_anywhere=False,
                                                        finalize=True, background_color=cor_clara)

                                                    stop_detalhes_tarefa = False

                                                    while not stop_detalhes_tarefa:
                                                        event_detalhes_tarefa, values_detalhes_tarefa = window_detalhes_tarefa.read()

                                                        if event_detalhes_tarefa in (sg.WIN_CLOSED, 'Fechar'):
                                                            stop_detalhes_tarefa = True
                                                            window_detalhes_tarefa.close()
                                        

                                    else:
                                        janelaErro("Não foram encontradas tarefas com a data de vencimento informada!")
            
                            elif eventos10 == 'Sair':
                                stop10 = True

                        window10.close()

                    
                    elif eventos8 == 'Prioridade': 
                        window8.close()
                        resultados3 = []

                        layout_prioridade = [
                            [sg.Text('Escolha a prioridade:', size=(20, 1), font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura)],
                            [sg.Button('Baixa', size=(10, 2), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)),
                            sg.Button('Média', size=(10, 2), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)),
                            sg.Button('Alta', size=(10, 2), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)),
                            sg.Button('Urgente', size=(10, 2), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura))],
                            [sg.Button('Cancelar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))]
                        ]

                        window_prioridade = sg.Window(title="Consultar tarefa pela prioridade", resizable=True, background_color=cor_clara).Layout(layout_prioridade)
                        stop_prioridade = False

                        while not stop_prioridade:
                            eventos_prioridade, valores_prioridade = window_prioridade.read()

                            if eventos_prioridade in [sg.WIN_CLOSED, 'Cancelar']:
                                stop_prioridade = True
                            
                            elif eventos_prioridade in ['Baixa', 'Média', 'Alta', 'Urgente']:
                                prioridade_escolhida = eventos_prioridade
                                tarefas_prioridade = consultarPrioridade(prioridade_escolhida, BD)

                                if tarefas_prioridade:
                                        tarefas_info13 = [f"{tarefa['id']} : {tarefa['titulo']} : {tarefa['descricao']} : {tarefa['data_vencimento']} : {tarefa['prioridade']} : {tarefa['categoria']} : {tarefa['concluida']}" for tarefa in tarefas_prioridade]

                                        layout_titulo102 = [
                                            [sg.Text('Selecione a tarefa:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura)],
                                            [sg.Listbox(values=tarefas_info13, size=(80, 10), key='-TAREFAS-', pad=((0, 0), (15, 10)), enable_events=True)],
                                            [sg.Button('Sair', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))]
                                        ]

                                        window_titulo102 = sg.Window('Selecionar Tarefa', layout_titulo102, grab_anywhere=False, finalize=True,
                                        background_color=cor_clara)

                                        stoptitulo102 = False

                                        while not stoptitulo102:
                                            eventtitulo102, valuestitulo102 = window_titulo102.read()

                                            if eventtitulo102 in (sg.WIN_CLOSED, 'Sair'):
                                                stoptitulo102 = True
                                                window_titulo102.close()

                                            elif eventtitulo102 == '-TAREFAS-':
                                                selected_index112 = valuestitulo102['-TAREFAS-'][0]

                                                if selected_index112 is not None:
                                                    selected_index13 = selected_index112.split(':')

                        # Agora você pode usar selected_tarefa para exibir os detalhes na nova janela
                                                    detalhes_tarefa_layout = [
                                                        [sg.Text(f"Tarefa Selecionada:\n\nTítulo: {selected_index13[1]}\n"
                                                        f"Descrição: {selected_index13[2]}\n"
                                                        f"Data de Vencimento: {selected_index13[3]}\n"
                                                        f"Prioridade: {selected_index13[4]}\n"
                                                        f"Categoria: {selected_index13[5]}\n"
                                                        f"Concluída: {selected_index13[6]}", text_color=cor_escura,background_color=cor_clara)],
                                                        [sg.Button('Fechar', size=(10, 1), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura))]
                                                    ]

                                                    window_detalhes_tarefa = sg.Window('Detalhes Tarefa', detalhes_tarefa_layout, grab_anywhere=False,
                                                        finalize=True, background_color=cor_clara)

                                                    stop_detalhes_tarefa = False

                                                    while not stop_detalhes_tarefa:
                                                        event_detalhes_tarefa, values_detalhes_tarefa = window_detalhes_tarefa.read()

                                                        if event_detalhes_tarefa in (sg.WIN_CLOSED, 'Fechar'):
                                                            stop_detalhes_tarefa = True
                                                            window_detalhes_tarefa.close()

                                        window["-Dados-"].update("Tarefas consultadas com sucesso!")

                                else:
                                    janelaErro("Não foram encontradas tarefas com a data de vencimento informada!")


                        window_prioridade.close()

                    elif eventos8 == 'Estado': 
                        window8.close()
                        resultados4 = []

                        layout_estado= [
                            [sg.Text('Escolha o estado:', size=(20, 1), font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura)],
                            [sg.Button('Concluído', size=(10, 2), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)),
                            sg.Button('Não Concluído', size=(12, 2), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura))],
                            [sg.Button('Cancelar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))]
                        ]

                        window_estado = sg.Window(title="Consultar tarefa pelo estado!", resizable=True, background_color=cor_clara).Layout(layout_estado)
                        stop_estado = False

                        while not stop_estado:
                            eventos_estado, valores_estado = window_estado.read()

                            if eventos_estado in [sg.WIN_CLOSED, 'Cancelar']:
                                stop_estado = True
                            
                            elif eventos_estado in ['Concluído','Não Concluído']:
                                estado_escolhido = eventos_estado
                                tarefas_estado = consultarEstado(estado_escolhido, BD)

                                if tarefas_estado:
                                        tarefas_info14 = [f"{tarefa['id']} : {tarefa['titulo']} : {tarefa['descricao']} : {tarefa['data_vencimento']} : {tarefa['prioridade']} : {tarefa['categoria']} : {tarefa['concluida']}" for tarefa in tarefas_estado]

                                        layout_titulo14 = [
                                            [sg.Text('Selecione a tarefa:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura)],
                                            [sg.Listbox(values=tarefas_info14, size=(80, 10), key='-TAREFAS-', pad=((0, 0), (15, 10)), enable_events=True)],
                                            [sg.Button('Sair', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))]
                                        ]

                                        window_titulo14 = sg.Window('Selecionar Tarefa', layout_titulo14, grab_anywhere=False, finalize=True,
                                        background_color=cor_clara)

                                        stoptitulo14 = False

                                        while not stoptitulo14:
                                            eventtitulo14, valuestitulo14 = window_titulo14.read()

                                            if eventtitulo14 in (sg.WIN_CLOSED, 'Sair'):
                                                stoptitulo14 = True
                                                window_titulo14.close()

                                            elif eventtitulo14 == '-TAREFAS-':
                                                selected_index14 = valuestitulo14['-TAREFAS-'][0]

                                                if selected_index14 is not None:
                                                    selected_index14 = selected_index14.split(':')

                        # Agora você pode usar selected_tarefa para exibir os detalhes na nova janela
                                                    detalhes_tarefa_layout = [
                                                        [sg.Text(f"Tarefa Selecionada:\n\nTítulo: {selected_index14[1]}\n"
                                                        f"Descrição: {selected_index14[2]}\n"
                                                        f"Data de Vencimento: {selected_index14[3]}\n"
                                                        f"Prioridade: {selected_index14[4]}\n"
                                                        f"Categoria: {selected_index14[5]}\n"
                                                        f"Concluída: {selected_index14[6]}", text_color=cor_escura,background_color=cor_clara)],
                                                        [sg.Button('Fechar', size=(10, 1), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura))]
                                                    ]

                                                    window_detalhes_tarefa = sg.Window('Detalhes Tarefa', detalhes_tarefa_layout, grab_anywhere=False,
                                                        finalize=True, background_color=cor_clara)

                                                    stop_detalhes_tarefa = False

                                                    while not stop_detalhes_tarefa:
                                                        event_detalhes_tarefa, values_detalhes_tarefa = window_detalhes_tarefa.read()

                                                        if event_detalhes_tarefa in (sg.WIN_CLOSED, 'Fechar'):
                                                            stop_detalhes_tarefa = True
                                                            window_detalhes_tarefa.close()

                                        window["-Dados-"].update("Tarefas consultadas com sucesso!")

                                else:
                                    janelaErro("Não foram encontradas tarefas com a data de vencimento informada!")     

                        window_estado.close()

                    elif eventos8 == 'Categoria':
                        window8.close()
                        resultados5 = []
                        
                        layoutcategoria = [
                            [sg.Text('Categoria:', size=(14, 1), expand_x=True, font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura)],
                            [sg.Combo(values=listacategoria(BD), key='-CATEGORIA-', font=("Cooper Hewitt", 12),background_color=cor_escura, text_color=cor_clara)],
                            [sg.Button('OK', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12)),
                            sg.Button('Sair', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))],
                        ]
                        
                        window_cat = sg.Window(title="Consultar tarefa pela categoria", resizable=True, background_color=cor_clara).Layout(layoutcategoria)
                        stopcat = False
                        
                        while not stopcat:
                            eventos_cat, valores_cat = window_cat.read()

                            if eventos_cat in [sg.WIN_CLOSED, 'Exit']:
                                stopcat = True

                            elif eventos_cat == 'OK':
                                resultados5 = []
                                tarefas_cat = consultarCategoria(valores_cat['-CATEGORIA-'], BD)

                                if tarefas_cat:
                                    tarefas_info15 = [f"{tarefa['id']} : {tarefa['titulo']} : {tarefa['descricao']} : {tarefa['data_vencimento']} : {tarefa['prioridade']} : {tarefa['categoria']} : {tarefa['concluida']}" for tarefa in tarefas_cat]

                                    layout_titulo15 = [
                                        [sg.Text('Selecione a tarefa:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura)],
                                        [sg.Listbox(values=tarefas_info15, size=(80, 10), key='-TAREFAS-', pad=((0, 0), (15, 10)), enable_events=True)],
                                        [sg.Button('Sair', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))]
                                    ]

                                    window_titulo15 = sg.Window('Selecionar Tarefa', layout_titulo15, grab_anywhere=False, finalize=True,
                                        background_color=cor_clara)

                                    stoptitulo15 = False

                                    while not stoptitulo15:
                                        eventtitulo15, valuestitulo15 = window_titulo15.read()

                                        if eventtitulo15 in (sg.WIN_CLOSED, 'Sair'):
                                            stoptitulo15 = True
                                            window_titulo15.close()

                                        elif eventtitulo15 == '-TAREFAS-':
                                            selected_index15 = valuestitulo15['-TAREFAS-'][0]

                                            if selected_index15 is not None:
                                                selected_index15 = selected_index15.split(':')

                        # Agora você pode usar selected_tarefa para exibir os detalhes na nova janela
                                                detalhes_tarefa_layout = [
                                                    [sg.Text(f"Tarefa Selecionada:\n\nTítulo: {selected_index15[1]}\n"
                                                    f"Descrição: {selected_index15[2]}\n"
                                                    f"Data de Vencimento: {selected_index15[3]}\n"
                                                    f"Prioridade: {selected_index15[4]}\n"
                                                    f"Categoria: {selected_index15[5]}\n"
                                                    f"Concluída: {selected_index15[6]}", text_color=cor_escura,background_color=cor_clara)],
                                                    [sg.Button('Fechar', size=(10, 1), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura))]
                                                ]

                                                window_detalhes_tarefa = sg.Window('Detalhes Tarefa', detalhes_tarefa_layout, grab_anywhere=False,
                                                        finalize=True, background_color=cor_clara)

                                                stop_detalhes_tarefa = False

                                                while not stop_detalhes_tarefa:
                                                    event_detalhes_tarefa, values_detalhes_tarefa = window_detalhes_tarefa.read()

                                                    if event_detalhes_tarefa in (sg.WIN_CLOSED, 'Fechar'):
                                                        stop_detalhes_tarefa = True
                                                        window_detalhes_tarefa.close()

                                

                            elif eventos_cat == 'Sair':
                                stopcat = True

                        window_cat.close()

        elif eventos == 'Alterar tarefa':
            if BD == None:
                janelaErro ("Introduza primeiro uma base de dados!")
            
            elif Guardada == 0:
                janelaErro ("Guarde primeiro a base de dados!")
            
            else:
                window["-Dados-"].update("A alterar dados de uma tarefa...")

                layout_alterar_dados = [
                    [sg.Text('Escolha como quer encontrar a tarefa:', size=(45, 1), font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura)],
                    [sg.Button('Data de Vencimento', font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)),
                    sg.Button('Categoria', font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)),
                    sg.Button('Prioridade', font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura))],
                    [sg.Button('Retornar ao Menu', font=("Cooper Hewitt", 14), button_color=(cor_clara, cor_escura))]
                ] 

                window_alterar_dados = sg.Window(title="Alterar Dados de uma Tarefa", resizable=True, background_color=cor_clara).Layout(layout_alterar_dados)
                stop_alterar = False 

                while not stop_alterar:
                    eventos_alterar, valoresalterar = window_alterar_dados.read()

                    if eventos_alterar in [sg.WIN_CLOSED, 'Exit'] or eventos_alterar == 'Retornar ao Menu':
                        stop_alterar = True 
                        window_alterar_dados.close()
                    
                    elif eventos_alterar == 'Data de Vencimento':
                        window_alterar_dados.close()
                        resultadosalt = []

                        layout_alterar_tarefa = [
                            [sg.Text('Escolha a data:', size=(45, 1), expand_x=True, font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura)],
                            [sg.CalendarButton('Escolha a Data', target='-DATA-', font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)),
                            sg.InputText("", key='-DATA-', readonly=True, font=("Cooper Hewitt", 12))],
                            [sg.Button('Consultar', font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura))],
                            [sg.Button('Retornar ao Menu', font=("Cooper Hewitt", 14), button_color=(cor_clara, cor_escura))]
                        ]

                        window_alterar_tarefa = sg.Window(title="Alterar Tarefa", resizable=True, background_color=cor_clara, layout=layout_alterar_tarefa)

                        stop_alterar_tarefa = False

                        while not stop_alterar_tarefa:
                            eventos_alterar_tarefa, valores_alterar_tarefa = window_alterar_tarefa.read()

                            if eventos_alterar_tarefa in [sg.WINDOW_CLOSED, 'Retornar ao Menu']:
                                stop_alterar_tarefa = True
                                window_alterar_tarefa.close()

                            elif eventos_alterar_tarefa == 'Consultar':
                                if '-DATA-' in valores_alterar_tarefa and valores_alterar_tarefa['-DATA-']:
                                    window_alterar_tarefa.close()
                                    data_selecionada_split = valores_alterar_tarefa['-DATA-'].split()

            # Verifica se a lista tem pelo menos um elemento antes de acessar o índice 0
                                    if data_selecionada_split:
                                        data_selecionada1 = data_selecionada_split[0]
                                        tarefas_na_data = consultardatavencimento(data_selecionada1, BD)
                    

                                        if tarefas_na_data:
                                            tarefas_info = [f"{tarefa['id']}:{tarefa['titulo']}:{tarefa['descricao']}:{tarefa['data_vencimento']}:{tarefa['prioridade']}:{tarefa['categoria']}:{tarefa['concluida']}" for tarefa in tarefas_na_data]

                                            layout_consultar_tarefas = [
                                                [sg.Listbox(tarefas_info, size=(80, 10), key="-LIST-", font=("Cooper Hewitt", 12), pad=((0, 0), (15, 10)), enable_events=True)],
                                                [sg.Button('Cancelar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))]
                                            ] 
                                    
                                            window_consultar_tarefas = sg.Window(title="Consultar Tarefas na Data", resizable=True, background_color=cor_clara,finalize=True, layout=layout_consultar_tarefas)

                                            stop_consultar_tarefas = False

                                            while not stop_consultar_tarefas:
                                                eventos_consultar_tarefas, valores_consultar_tarefas = window_consultar_tarefas.read()

                                                if eventos_consultar_tarefas in (sg.WINDOW_CLOSED, 'Cancelar'):
                                                    window_consultar_tarefas.close()
                                                    stop_consultar_tarefas = True

                                                elif eventos_consultar_tarefas == '-LIST-':
                                                    window_alterar_tarefa.close()
                                                    tarefa_selecionada = valores_consultar_tarefas['-LIST-'][0]
                                                    tarefa_info1 = tarefa_selecionada.split(':')

    # Obtém os valores individuais
                                                    tarefa_conc = tarefa_info1[6]
                                                    tarefa_titulo = tarefa_info1[1]
                                                    tarefa_descricao = tarefa_info1[2]
                                                    tarefa_data = tarefa_info1[3]
                                                    tarefa_prioridade = tarefa_info1[4]
                                                    tarefa_categoria = tarefa_info1[5]
                
                                                    descriptions = [tarefa['descricao'] for tarefa in tarefas_na_data if tarefa['titulo'] == tarefa_selecionada]
                                                    descricao_default = descriptions[0] if descriptions else ''

                                                    layout_alterar_detalhes_tarefa = [
                                                        [sg.Text(f'Alterar detalhes da tarefa "{tarefa_titulo}":', size=(45, 1), expand_x=True, font=("Cambria", 12, "bold"), background_color=cor_clara, text_color=cor_escura)],
                                                        [sg.Text('Título:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura),
                                                        sg.InputText(default_text=tarefa_titulo,key='novo_titulo')],
                                                        [sg.Text('Descrição:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura),
                                                        sg.InputText(default_text=tarefa_descricao,key='nova_descricao')],
                                                        [sg.Text('Prioridade:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura),
                                                        sg.InputText(default_text=tarefa_prioridade,key='nova_prioridade')],
                                                        [sg.Text('Categoria:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura),
                                                        sg.InputText(default_text=tarefa_categoria,key='nova_categoria')],
                                                        [sg.Text('Concluído:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura),
                                                        sg.InputText(default_text=tarefa_conc,key='novo_conc')],
                                                        [sg.Text('Data de Vencimento:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura),
                                                        sg.InputText(default_text=tarefa_data,key='nova_data')],
                                                        [sg.Button('Salvar Alterações', button_color=(cor_clara, cor_escura), font=("Cambria", 12)),
                                                        sg.Button('Cancelar', button_color=(cor_clara, cor_escura), font=("Cambria", 12))]
                                                    ]
    
        
                                                    window_alterar_detalhes_tarefa = sg.Window(title="Alterar Detalhes da Tarefa", resizable=True, background_color=cor_clara, finalize=True, layout=layout_alterar_detalhes_tarefa)

                                                    stop_alterar_detalhes_tarefa = False 


                                                    while not stop_alterar_detalhes_tarefa:
                                                        eventos_alterar_detalhes_tarefa, valores_alterar_detalhes_tarefa = window_alterar_detalhes_tarefa.read()

                                                        if eventos_alterar_detalhes_tarefa in (sg.WINDOW_CLOSED, 'Cancelar'):
                                                            stop_alterar_detalhes_tarefa = True 

                                                        elif eventos_alterar_detalhes_tarefa == 'Salvar Alterações':
                                                            novo_titulo = valores_alterar_detalhes_tarefa['novo_titulo']
                                                            nova_descricao = valores_alterar_detalhes_tarefa['nova_descricao']
                                                            nova_prioridade = valores_alterar_detalhes_tarefa['nova_prioridade']
                                                            nova_categoria = valores_alterar_detalhes_tarefa['nova_categoria']
                                                            nova_conc = valores_alterar_detalhes_tarefa['novo_conc']
                                                            nova_data_vencimento = valores_alterar_detalhes_tarefa['nova_data']
                                                            id_tarefa_selecionada = int(tarefa_info1[0])
                                    

                                                            if alterarDetalhesTarefa(id_tarefa_selecionada, novo_titulo, nova_descricao,nova_prioridade,nova_categoria,nova_conc, nova_data_vencimento, BD):
                                                                sg.popup('Alterações salvas com sucesso!', title='Sucesso',background_color=cor_clara, text_color=cor_escura)
                                                                stop_alterar_detalhes_tarefa = True
                                                            else:
                                                                sg.popup_error('Falha ao salvar as alterações.', title='Erro',background_color=cor_clara, text_color=cor_escura)
                                                    window_alterar_detalhes_tarefa.close()
                                                    window_consultar_tarefas.close()
                                        
                                        else:
                                            sg.popup('Não há tarefas na data selecionada.', title='Sem Tarefas',background_color=cor_clara, text_color=cor_escura)
                                    
                                            stop_alterar_tarefa = True
                                else:
                                    sg.popup('Escolha uma data antes de consultar.', title='Aviso', background_color=cor_clara, text_color=cor_escura)
                    
                    
                    
                    elif eventos_alterar == 'Categoria':
                        window_alterar_dados.close()
                        resultadosalt = []

                        layout_alterar_categoria = [
                            [sg.Text('Categoria:', size=(14, 1), expand_x=True, font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura)],
                            [sg.Combo(values=listacategoria(BD), key='-CATEGORIA-', font=("Cooper Hewitt", 12),background_color=cor_escura, text_color=cor_clara)],
                            [sg.Button('Consultar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12)),
                            sg.Button('Sair', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))],
                            [sg.Listbox(values=[], size=(80, 10), pad=((0, 0), (15, 10)), horizontal_scroll=True, key="-RESC-")]            
                        ]

                        window_alterar_categoria = sg.Window(title="Alterar tarefa", resizable=True, background_color=cor_clara).Layout(layout_alterar_categoria)

                        stop_alterar_categoria = False

                        while not stop_alterar_categoria:
                            eventos_alterar_categoria, valores_alterar_categoria = window_alterar_categoria.read()

                            if eventos_alterar_categoria in (sg.WINDOW_CLOSED, 'Retornar ao Menu'):
                                stop_alterar_categoria = True
                            
                            elif eventos_alterar_categoria == 'Consultar':
                                categoria_selecionada = valores_alterar_categoria['-CATEGORIA-']

                                if categoria_selecionada:
                                    window_alterar_categoria.close()
                                    tarefas_na_categoria = consultarCategoria(categoria_selecionada, BD)

                                    if tarefas_na_categoria:
                                        tarefas_info0 = [f"{tarefa['id']}:{tarefa['titulo']}:{tarefa['descricao']}:{tarefa['data_vencimento']}:{tarefa['prioridade']}:{tarefa['categoria']}:{tarefa['concluida']}" for tarefa in tarefas_na_categoria]

                                        layout_consultar_tarefas_categoria = [
                                            [sg.Listbox(tarefas_info0, size=(80, 10), key="-LIST-", font=("Cooper Hewitt", 12), pad=((0, 0), (15, 10)), enable_events=True)],
                                            [sg.Button('Cancelar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))]
                                        ]

                                        window_consultar_tarefas_categoria = sg.Window(title="Consultar Tarefas na Categoria", resizable=True, background_color=cor_clara, finalize=True, layout=layout_consultar_tarefas_categoria)

                                        stop_consultar_tarefas_categoria = False

                                        while not stop_consultar_tarefas_categoria:
                                            eventos_consultar_tarefas_categoria, valores_consultar_tarefas_categoria = window_consultar_tarefas_categoria.read()

                                            if eventos_consultar_tarefas_categoria in (sg.WINDOW_CLOSED, 'Cancelar'):
                                                window_consultar_tarefas_categoria.close()
                                                stop_consultar_tarefas_categoria = True

                                            elif eventos_consultar_tarefas_categoria == '-LIST-':
                                                window_alterar_categoria.close()
                                                tarefa_selecionada_categoria = valores_consultar_tarefas_categoria['-LIST-'][0]
                                                tarefa_info2 = tarefa_selecionada_categoria.split(':')

                        # Obtém os valores individuais
                                                tarefa_conc1 = tarefa_info2[6]
                                                tarefa_titulo1 = tarefa_info2[1]
                                                tarefa_descricao1 = tarefa_info2[2]
                                                tarefa_data1 = tarefa_info2[3]
                                                tarefa_prioridade1 = tarefa_info2[4]
                                                tarefa_categoria1 = tarefa_info2[5]

                                                descriptions = [tarefa['descricao'] for tarefa in tarefas_na_categoria if tarefa['titulo'] == tarefa_selecionada_categoria]
                                                descricao_default = descriptions[0] if descriptions else ''


                                                layout_alterar_detalhes_tarefa = [
                                                    [sg.Text(f'Alterar detalhes da tarefa "{tarefa_titulo1}":', size=(45, 1), expand_x=True, font=("Cambria", 12, "bold"), background_color=cor_clara, text_color=cor_escura)],
                                                    [sg.Text('Título:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura),
                                                    sg.InputText(default_text=tarefa_titulo1,key='novo_titulo')],
                                                    [sg.Text('Descrição:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura),
                                                    sg.InputText(default_text=tarefa_descricao1,key='nova_descricao')],
                                                    [sg.Text('Prioridade:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura),
                                                    sg.InputText(default_text=tarefa_prioridade1,key='nova_prioridade')],
                                                    [sg.Text('Categoria:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura),
                                                    sg.InputText(default_text=tarefa_categoria1,key='nova_categoria')],
                                                    [sg.Text('Concluído:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura),
                                                    sg.InputText(default_text=tarefa_conc1,key='novo_conc')],
                                                    [sg.Text('Data de Vencimento:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura),
                                                    sg.InputText(default_text=tarefa_data1,key='nova_data')],
                                                    [sg.Button('Salvar Alterações', button_color=(cor_clara, cor_escura), font=("Cambria", 12)),
                                                    sg.Button('Cancelar', button_color=(cor_clara, cor_escura), font=("Cambria", 12))]
                                                ]
    
        
                                                window_alterar_detalhes_tarefa = sg.Window(title="Alterar Detalhes da Tarefa", resizable=True, background_color=cor_clara, finalize=True, layout=layout_alterar_detalhes_tarefa)

                                                stop_alterar_detalhes_tarefa = False 

                                                while not stop_alterar_detalhes_tarefa:
                                                    eventos_alterar_detalhes_tarefa_categoria, valores_alterar_detalhes_tarefa_categoria = window_alterar_detalhes_tarefa.read()

                                                    if eventos_alterar_detalhes_tarefa_categoria in (sg.WINDOW_CLOSED, 'Exit','Cancelar'):
                                                        stop_alterar_detalhes_tarefa = True 
                                                        window_alterar_detalhes_tarefa.close()

                                                    elif eventos_alterar_detalhes_tarefa_categoria == 'Salvar Alterações':
                                                        novo_titulo1 = valores_alterar_detalhes_tarefa_categoria['novo_titulo']
                                                        nova_descricao1 = valores_alterar_detalhes_tarefa_categoria['nova_descricao']
                                                        nova_prioridade1 = valores_alterar_detalhes_tarefa_categoria['nova_prioridade']
                                                        nova_categoria1 = valores_alterar_detalhes_tarefa_categoria['nova_categoria']
                                                        nova_conc1 = valores_alterar_detalhes_tarefa_categoria['novo_conc']
                                                        nova_data_vencimento1 = valores_alterar_detalhes_tarefa_categoria['nova_data']
                                                        id_tarefa_selecionada1 = int(tarefa_info2[0])
                                    
                                                        if alterarDetalhesTarefa(id_tarefa_selecionada1, novo_titulo1, nova_descricao1,nova_prioridade1,nova_categoria1,nova_conc1, nova_data_vencimento1, BD):
                                                            sg.popup('Alterações salvas com sucesso!', title='Sucesso',background_color=cor_clara, text_color=cor_escura)
                                                            stop_alterar_detalhes_tarefa = True
                                                        else:
                                                            sg.popup_error('Falha ao salvar as alterações.', title='Erro',background_color=cor_clara, text_color=cor_escura)
                                                        
                                                        stop_alterar_detalhes_tarefa = True
        
                                                window_alterar_detalhes_tarefa.close()
                                                window_consultar_tarefas_categoria.close()                                    
                                    else:
                                        sg.popup('Não há tarefas na categoria selecionada.', title='Sem Tarefas',background_color=cor_clara, text_color=cor_escura)
                                    
                                        stop_alterar_tarefa = True
                                else:
                                    sg.popup('Escolha uma categoria antes de consultar.', title='Aviso', background_color=cor_clara, text_color=cor_escura)


                    elif eventos_alterar == 'Prioridade':
                        window_alterar_dados.close()
                        resultadosalti = []

                        layout_alterar_prioridade = [
                            [sg.Text('Prioridade:', size=(14, 1), expand_x=True, font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura)],
                            [sg.Combo(values=("Urgente","Alta","Média","Baixa"), key='-PRIORIDADE-', font=("Cooper Hewitt", 12),background_color=cor_escura, text_color=cor_clara)],
                            [sg.Button('Consultar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12)),
                            sg.Button('Sair', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))],
                            [sg.Listbox(values=[], size=(80, 10), pad=((0, 0), (15, 10)), horizontal_scroll=True, key="-RESC-")]            
                        ]

                        window_alterar_prioridade = sg.Window(title="Alterar tarefa", resizable=True, background_color=cor_clara).Layout(layout_alterar_prioridade)

                        stop_alterar_prioridade = False

                        while not stop_alterar_prioridade:
                            eventos_alterar_prioridade, valores_alterar_prioridade = window_alterar_prioridade.read()

                            if eventos_alterar_prioridade in (sg.WINDOW_CLOSED, 'Retornar ao Menu'):
                                stop_alterar_prioridade = True
                            
                            elif eventos_alterar_prioridade == 'Consultar':
                                prioridade_selecionada = valores_alterar_prioridade['-PRIORIDADE-']

                                if prioridade_selecionada:
                                    window_alterar_prioridade.close()
                                    tarefas_na_prioridade = consultarPrioridade(prioridade_selecionada, BD)

                                    if tarefas_na_prioridade:
                                        tarefas_info2 = [f"{tarefa['id']}:{tarefa['titulo']}:{tarefa['descricao']}:{tarefa['data_vencimento']}:{tarefa['prioridade']}:{tarefa['categoria']}:{tarefa['concluida']}" for tarefa in tarefas_na_prioridade]

                                        layout_consultar_tarefas_prioridade = [
                                            [sg.Listbox(tarefas_info2, size=(80, 10), key="-LIST-", font=("Cooper Hewitt", 12), pad=((0, 0), (15, 10)), enable_events=True)],
                                            [sg.Button('Cancelar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))]
                                        ]

                                        window_consultar_tarefas_prioridade = sg.Window(title="Consultar Tarefas na Prioridade", resizable=True, background_color=cor_clara, finalize=True, layout=layout_consultar_tarefas_prioridade)

                                        stop_consultar_tarefas_prioridade = False

                                        while not stop_consultar_tarefas_prioridade:
                                            eventos_consultar_tarefas_prioridade, valores_consultar_tarefas_prioridade = window_consultar_tarefas_prioridade.read()

                                            if eventos_consultar_tarefas_prioridade in (sg.WINDOW_CLOSED, 'Cancelar'):
                                                window_consultar_tarefas_prioridade.close()
                                                stop_consultar_tarefas_prioridade = True

                                            elif eventos_consultar_tarefas_prioridade == '-LIST-':
                                                window_alterar_prioridade.close()
                                                tarefa_selecionada_prioridade = valores_consultar_tarefas_prioridade['-LIST-'][0]
                                                tarefa_info3 = tarefa_selecionada_prioridade.split(':')

                        # Obtém os valores individuais
                                                tarefa_conc2 = tarefa_info3[6]
                                                tarefa_titulo2 = tarefa_info3[1]
                                                tarefa_descricao2 = tarefa_info3[2]
                                                tarefa_data2 = tarefa_info3[3]
                                                tarefa_prioridade2 = tarefa_info3[4]
                                                tarefa_categoria2 = tarefa_info3[5]

                                                descriptions = [tarefa['descricao'] for tarefa in tarefas_na_categoria if tarefa['titulo'] == tarefa_selecionada_prioridade]
                                                descricao_default = descriptions[0] if descriptions else ''


                                                layout_alterar_detalhes_tarefa = [
                                                    [sg.Text(f'Alterar detalhes da tarefa "{tarefa_titulo2}":', size=(45, 1), expand_x=True, font=("Cambria", 12, "bold"), background_color=cor_clara, text_color=cor_escura)],
                                                    [sg.Text('Título:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura),
                                                    sg.InputText(default_text=tarefa_titulo2,key='novo_titulo')],
                                                    [sg.Text('Descrição:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura),
                                                    sg.InputText(default_text=tarefa_descricao2,key='nova_descricao')],
                                                    [sg.Text('Prioridade:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura),
                                                    sg.InputText(default_text=tarefa_prioridade2,key='nova_prioridade')],
                                                    [sg.Text('Categoria:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura),
                                                    sg.InputText(default_text=tarefa_categoria2,key='nova_categoria')],
                                                    [sg.Text('Concluído:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura),
                                                    sg.InputText(default_text=tarefa_conc2,key='novo_conc')],
                                                    [sg.Text('Data de Vencimento:', size=(20, 1), font=("Cambria", 12), background_color=cor_clara, text_color=cor_escura),
                                                    sg.InputText(default_text=tarefa_data2,key='nova_data')],
                                                    [sg.Button('Salvar Alterações', button_color=(cor_clara, cor_escura), font=("Cambria", 12)),
                                                    sg.Button('Cancelar', button_color=(cor_clara, cor_escura), font=("Cambria", 12))]
                                                ]
    
        
                                                window_alterar_detalhes_tarefa = sg.Window(title="Alterar Detalhes da Tarefa", resizable=True, background_color=cor_clara, finalize=True, layout=layout_alterar_detalhes_tarefa)

                                                stop_alterar_detalhes_tarefa = False 

                                                while not stop_alterar_detalhes_tarefa:
                                                    eventos_alterar_detalhes_tarefa_prioridade, valores_alterar_detalhes_tarefa_prioridade = window_alterar_detalhes_tarefa.read()

                                                    if eventos_alterar_detalhes_tarefa_prioridade in (sg.WINDOW_CLOSED, 'Exit','Cancelar'):
                                                        stop_alterar_detalhes_tarefa = True 
                                                        window_alterar_detalhes_tarefa.close()

                                                    elif eventos_alterar_detalhes_tarefa_prioridade == 'Salvar Alterações':
                                                        novo_titulo2 = valores_alterar_detalhes_tarefa_prioridade['novo_titulo']
                                                        nova_descricao2 = valores_alterar_detalhes_tarefa_prioridade['nova_descricao']
                                                        nova_prioridade2 = valores_alterar_detalhes_tarefa_prioridade['nova_prioridade']
                                                        nova_categoria2 = valores_alterar_detalhes_tarefa_prioridade['nova_categoria']
                                                        nova_conc2 = valores_alterar_detalhes_tarefa_prioridade['novo_conc']
                                                        nova_data_vencimento2 = valores_alterar_detalhes_tarefa_prioridade['nova_data']
                                                        id_tarefa_selecionada2 = int(tarefa_info3[0])
                                    
                                                        if alterarDetalhesTarefa(id_tarefa_selecionada2, novo_titulo2, nova_descricao2,nova_prioridade2,nova_categoria2,nova_conc2, nova_data_vencimento2, BD):
                                                            sg.popup('Alterações salvas com sucesso!', title='Sucesso',background_color=cor_clara, text_color=cor_escura)
                                                            stop_alterar_detalhes_tarefa = True
                                                        else:
                                                            sg.popup_error('Falha ao salvar as alterações.', title='Erro',background_color=cor_clara, text_color=cor_escura)
                                                        
                                                        stop_alterar_detalhes_tarefa = True
        
                                                window_alterar_detalhes_tarefa.close()
                                                window_consultar_tarefas_prioridade.close()                                    
                                    else:
                                        sg.popup('Não há tarefas na categoria selecionada.', title='Sem Tarefas',background_color=cor_clara, text_color=cor_escura)
                                    
                                        stop_alterar_tarefa = True
                                else:
                                    sg.popup('Escolha uma categoria antes de consultar.', title='Aviso', background_color=cor_clara, text_color=cor_escura)
        elif eventos == "Listagem":
            window["-Dados-"].update("A listar...")
            
            if BD == None:
                janelaErro ("Introduza primeiro uma base de dados!")
            
            elif Guardada == 0:
                janelaErro ("Guarde primeiro a base de dados!")

            else:
                categorias = listacategoria(BD)

                layout_listagem = [
                    [sg.Text ('Deseja listar tarefa por:', size= (45,1), expand_x= True, font=("Cambria", 15, "bold"),background_color=cor_clara,text_color=cor_escura)],
                    [sg.Button ('Prioridade', size=(12,1),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",12)),sg.Button ('Categoria', size=(12,1),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",12)),
                    sg.Button ('Estado', size=(10,1),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",12)),sg.Button ('Data de Vencimento', size=(12,2),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",12)),sg.Button ('Retornar ao Menu',font=("Cooper Hewitt", 14), button_color= (cor_clara,cor_escura))],     
                ]
            
                window_listagem = sg.Window(title="Listar tarefas", resizable=True, background_color=cor_clara, finalize=True, layout=layout_listagem)
                stop_listagem = False

                while not stop_listagem:
                    eventos_listagem, valores_listagem = window_listagem.read()    

                    if eventos_listagem in (sg.WINDOW_CLOSED, 'Retornar ao Menu'):
                        stop_listagem = True
                        window_listagem.close()


                    elif eventos_listagem == 'Prioridade': 
                        window_listagem.close()
                        resultados_p = []

                        layout_listagem_prioridade = [
                            [sg.Text('Escolha a prioridade:', size=(20, 1), font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura)],
                            [sg.Button('Baixa', size=(10, 2), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)),
                            sg.Button('Média', size=(10, 2), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)),
                            sg.Button('Alta', size=(10, 2), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)),
                            sg.Button('Urgente', size=(10, 2), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)),
                            sg.Button('Ordenada', size=(10, 2), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura))],
                            [sg.Listbox(values=[], size=(80, 10), pad=((0, 0), (15, 10)), horizontal_scroll=True, key="-RESL-")],
                            [sg.Button('Cancelar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))]
                        ]

                        window_listagem_prioridade = sg.Window(title="Listar as tarefas por prioridade", resizable=True, background_color=cor_clara).Layout(layout_listagem_prioridade)
                        stop_l_pri = False

                        while not stop_l_pri:
                            eventos_listagem_pri, valores_listagem_pri = window_listagem_prioridade.read()

                            if eventos_listagem_pri in [sg.WIN_CLOSED, 'Cancelar']:
                                stop_l_pri = True
                        
                            elif eventos_listagem_pri in ['Baixa', 'Média', 'Alta', 'Urgente']:
                                prioridade_l_escolhida = eventos_listagem_pri

                                tarefas_l_prioridade = listar_prioridade(BD,prioridade_l_escolhida)

                                if prioridade_l_escolhida not in listaprioridades(BD):
                                    resultados_p = ["Ainda não existem tarefas com essa prioridade!"]
                                else:
                                    resultados_p = [str(titulo) for titulo in tarefas_l_prioridade]

                                window_listagem_prioridade.find_element('-RESL-').Update(values=resultados_p)

                                window["-Dados-"].update("Tarefas listadas com sucesso!")
                            
                            elif eventos_listagem_pri == 'Ordenada':
                                
                                resultados_p = [str(titulo) for titulo in listapri(BD)]
                                window_listagem_prioridade.find_element('-RESL-').Update(values=resultados_p)

                            window["-Dados-"].update("Tarefas listadas com sucesso!")


                        window_listagem_prioridade.close()

                    elif eventos_listagem == 'Categoria':
                        window_listagem.close()
                        resultado_c = []
                        layout_listagem_categoria = [
                            [sg.Text('Categoria:', size=(14, 1), expand_x=True, font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura)],
                            [sg.Combo(values=listacategoria(BD), key="cat", font=("Cooper Hewitt", 12),background_color=cor_escura, text_color=cor_clara)],
                            [sg.Button('OK', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12)),
                            sg.Button('Sair', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))],
                            [sg.Listbox(values=[], size=(80, 10), pad=((0, 0), (15, 10)), horizontal_scroll=True, key="-RESC-")]            
                        ]


                        window_listagem_categoria = sg.Window(title="Listar as tarefas por categoria", resizable=True, background_color=cor_clara).Layout(layout_listagem_categoria)
                        stop_l_cat = False

                        while not stop_l_cat:
                            eventos_listagem_cat, valores_listagem_cat = window_listagem_categoria.read()

                            if eventos_listagem_cat in [sg.WIN_CLOSED, 'Sair']:
                                stop_l_cat = True
                        
                            elif 'cat' in valores_listagem_cat:
                                categoria_l_escolhida = valores_listagem_cat['cat']

                                tarefas_l_categoria = listar_categoria(BD,categoria_l_escolhida)

                                if eventos_listagem_cat == 'OK':
                                    resultado_c = [str(titulo) for titulo in tarefas_l_categoria]

                                    window_listagem_categoria.find_element('-RESC-').Update(values=resultado_c)

                                    window["-Dados-"].update("Tarefas listadas com sucesso!")


                        window_listagem_categoria.close()



                    elif eventos_listagem == 'Estado': 
                        window_listagem.close()
                        resultados_e = []

                        layout_listagem_estado = [
                            [sg.Text('Concluída:', size=(20, 1), font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura)],
                            [sg.Button('Concluída', size=(10, 2), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)),
                            sg.Button('Não Concluída', size=(12, 2), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura))],
                            [sg.Listbox(values=[], size=(80, 10), pad=((0, 0), (15, 10)), horizontal_scroll=True, key="-RESE-")],
                            [sg.Button('Cancelar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))]
                        ]

                        window_listagem_estado = sg.Window(title="Listar as tarefas por prioridade", resizable=True, background_color=cor_clara).Layout(layout_listagem_estado)
                        stop_l_est = False

                        while not stop_l_est:
                            eventos_listagem_est, valores_listagem_est = window_listagem_estado.read()

                            if eventos_listagem_est in [sg.WIN_CLOSED, 'Cancelar']:
                                stop_l_est = True
                                window_listagem_estado.close()
                        
                            elif eventos_listagem_est == 'Concluída':
                                estado_l_escolhida = True
                                tarefas_l_estado = listar_estado(BD, True)

                                
                                if not tarefas_l_estado:
                                    resultados_e = ["Ainda não existem tarefas concluídas!"]
                                else:
                                    resultados_e = [str(titulo) for titulo in tarefas_l_estado]
                                
                                window_listagem_estado.find_element('-RESE-').Update(values=resultados_e)
                                window["-Dados-"].update("Tarefas listadas com sucesso!")

                                #window_listagem_estado.close()

                            elif eventos_listagem_est == 'Não Concluída':
                                estado_l_escolhida = False
                                tarefas_l_estado = listar_estado(BD, False)
                                    
                                if not tarefas_l_estado:
                                    resultados_e = ["Ainda não existem tarefas concluídas!"]
                                else:
                                    resultados_e = [str(titulo) for titulo in tarefas_l_estado]
                                
                                window_listagem_estado.find_element('-RESE-').Update(values=resultados_e)
                                window["-Dados-"].update("Tarefas listadas com sucesso!")

                        #window_listagem_estado.close()
                    elif eventos_listagem == 'Data de Vencimento':
                        layout_listagem_data = [
                            [sg.Text('Listagem ordenada por Data de Vencimento', size=(40, 1), font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura)],
                            [sg.Listbox(values=[str(titulo) for titulo in listadata(BD)], size=(80, 10), pad=((0, 0), (15, 10)), horizontal_scroll=True, key="-RESL-")],
                            [sg.Button('Cancelar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))]
                        ]

                        window_listagem_data = sg.Window(title="Listar as tarefas por Data", resizable=True, background_color=cor_clara).Layout(layout_listagem_data)
                        stop_l_data = False

                        while not stop_l_data:
                            eventos_listagem_data, valores_listagem_data = window_listagem_data.read()
                            if eventos_listagem_data in (sg.WIN_CLOSED, 'Cancelar'):
                                stop_l_data = True
                                window_listagem_data.close()
                                window_listagem.close()


                        

                            window["-Dados-"].update("Tarefas listadas com sucesso!")

                       




        elif eventos == "Eliminar tarefa":
            window["-Dados-"].update("A eliminar...")
            
            if BD == None:
                janelaErro ("Introduza primeiro uma base de dados!")
            
            elif Guardada == 0:
                janelaErro ("Guarde primeiro a base de dados!")

            else:
                layout_eliminar = [
                    [sg.Text ('Deseja eliminar tarefa por:', size= (45,1), expand_x= True, font=("Cambria", 15, "bold"),background_color=cor_clara,text_color=cor_escura)],
                    [sg.Button ('Estado', size=(12,1),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",12)),
                    sg.Button ('Categoria', size=(12,1),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",12)),
                    sg.Button ('Data de Vencimento', size=(17,1),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",12)),
                    sg.Button ('Título', size=(12,1),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",12)),
                    sg.Button ('Retornar ao Menu',font=("Cooper Hewitt", 14), button_color= (cor_clara,cor_escura))],     
                ]
            
                window_eliminar = sg.Window(title="Eliminar tarefas", resizable=True, background_color=cor_clara, finalize=True, layout=layout_eliminar)
                stop_eliminar = False

                while not stop_eliminar:
                    eventos_eliminar, valores_eliminar = window_eliminar.read()    

                    if eventos_eliminar in (sg.WINDOW_CLOSED, 'Retornar ao Menu'):
                        stop_eliminar = True
                        window_eliminar.close()


                    elif eventos_eliminar == 'Estado': 
                        window_eliminar.close()
                        resultados_e = []

                        layout_excluir_tarefa = [
                            [sg.Text('Estado:', size=(14, 1), expand_x=True, font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura)],
                            [sg.Button('Concluídas', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12)),
                            sg.Button('Não Concluídas', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))],
                            [sg.Listbox(values=[], size=(80, 10), pad=((0, 0), (15, 10)), horizontal_scroll=True, key="-LIST-",enable_events=True, bind_return_key=True)],
                            [sg.Button('Eliminar Tarefa', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12)),
                            sg.Button('Cancelar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))]
                        ]


                        window_excluir_tarefa = sg.Window(title="Eliminar Tarefa pelo Estado", resizable=True, background_color=cor_clara).Layout(layout_excluir_tarefa)

                        stop_excluir_tarefa = False

                        while not stop_excluir_tarefa:
                            eventos_excluir_tarefa, valores_excluir_tarefa = window_excluir_tarefa.read()

                            if eventos_excluir_tarefa in (sg.WINDOW_CLOSED, 'Cancelar'):
                                stop_excluir_tarefa = True

                            elif eventos_excluir_tarefa == 'Concluídas' or eventos_excluir_tarefa == 'Não Concluídas':
                                estado_selecionado = eventos_excluir_tarefa
                                tarefas_filtradas = consultarEstado(estado_selecionado, BD)
                                tarefas_info = [f"{tarefa['id']}:{tarefa['titulo']}:{tarefa['descricao']}:{tarefa['data_vencimento']}:{tarefa['prioridade']}:{tarefa['categoria']}:{tarefa['concluida']}" for tarefa in tarefas_filtradas]
                                window_excluir_tarefa["-LIST-"].update(values=tarefas_info)
                            
                            elif eventos_excluir_tarefa == '-LIST-' :
                                if valores_excluir_tarefa['-LIST-']:
                                    tarefa_selecionada = valores_excluir_tarefa['-LIST-'][0].split(':')
                                    id_tarefa_selecionada = int(tarefa_selecionada[0])

                # Exclui a tarefa
                                    if eliminarTarefa(id_tarefa_selecionada, BD):
                                        sg.popup('Tarefa excluída com sucesso!', title='Sucesso', background_color=cor_clara, text_color=cor_escura)
                                        stop_excluir_tarefa = True
                                    else:
                                        sg.popup_error('Falha ao excluir a tarefa.', title='Erro', background_color=cor_clara, text_color=cor_escura)
                        
                        window_excluir_tarefa.close()
                        window["-Dados-"].update("Tarefa eliminada com sucesso!")


                    elif eventos_eliminar=="Categoria":
                        window_eliminar.close()
                        resultados_e = []

                        layout_excluir_por_categoria = [
                            [sg.Text('Escolha a categoria para excluir tarefas:', size=(45, 1), expand_x=True, font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura)],
                            [sg.Combo(values=listacategoria(BD), key='-CATEGORIA_EXCLUIR-', font=("Cooper Hewitt", 12), background_color=cor_escura, text_color=cor_clara)],
                            [sg.Button('Consultar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12)),
                            sg.Button('Cancelar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))],
                            [sg.Listbox(values=[], size=(80, 10), pad=((0, 0), (15, 10)), horizontal_scroll=True, key="-LIST_EXCLUIR-")]
                        ]

                        window_excluir_por_categoria = sg.Window(title="Excluir Tarefa por Categoria", resizable=True, background_color=cor_clara).Layout(layout_excluir_por_categoria)

                        stop_excluir_por_categoria = False

                        while not stop_excluir_por_categoria:
                            eventos_excluir_por_categoria, valores_excluir_por_categoria = window_excluir_por_categoria.read()

                            if eventos_excluir_por_categoria in (sg.WINDOW_CLOSED, 'Cancelar'):
                                stop_excluir_por_categoria = True

                            elif eventos_excluir_por_categoria == 'Consultar':
                                categoria_selecionada_excluir = valores_excluir_por_categoria['-CATEGORIA_EXCLUIR-']

                                if categoria_selecionada_excluir:
                                    window_excluir_por_categoria.close()
                                    tarefas_na_categoria_excluir = consultarCategoria(categoria_selecionada_excluir, BD)

                                    if tarefas_na_categoria_excluir:
                                        tarefas_info_excluir = [f"{tarefa['id']}:{tarefa['titulo']}:{tarefa['descricao']}:{tarefa['data_vencimento']}:{tarefa['prioridade']}:{tarefa['categoria']}:{tarefa['concluida']}" for tarefa in tarefas_na_categoria_excluir]

                                        layout_consultar_tarefas_por_categoria = [
                                            [sg.Listbox(tarefas_info_excluir, size=(80, 10), key="-LIST_EXCLUIR-", font=("Cooper Hewitt", 12), pad=((0, 0), (15, 10)), enable_events=True)],
                                            [sg.Button('Cancelar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))]
                                        ]

                                        window_consultar_tarefas_por_categoria = sg.Window(title="Consultar Tarefas na Categoria", resizable=True, background_color=cor_clara, finalize=True, layout=layout_consultar_tarefas_por_categoria)

                                        stop_consultar_tarefas_por_categoria = False

                                        while not stop_consultar_tarefas_por_categoria:
                                            eventos_consultar_tarefas_por_categoria, valores_consultar_tarefas_por_categoria = window_consultar_tarefas_por_categoria.read()

                                            if eventos_consultar_tarefas_por_categoria in (sg.WINDOW_CLOSED, 'Cancelar'):
                                                window_consultar_tarefas_por_categoria.close()
                                                stop_consultar_tarefas_por_categoria = True

                                            elif eventos_consultar_tarefas_por_categoria == '-LIST_EXCLUIR-' and valores_consultar_tarefas_por_categoria["-LIST_EXCLUIR-"]:
                                                tarefa_selecionada_excluir = valores_consultar_tarefas_por_categoria["-LIST_EXCLUIR-"][0]
                                                tarefa_info_excluir = tarefa_selecionada_excluir.split(':')

                                # Obtém o ID da tarefa selecionada
                                                id_tarefa_selecionada_excluir = int(tarefa_info_excluir[0])

                                # Exclui a tarefa
                                                if eliminarTarefa(id_tarefa_selecionada_excluir, BD):
                                                    sg.popup('Tarefa excluída com sucesso!', title='Sucesso', background_color=cor_clara, text_color=cor_escura)
                                                    stop_consultar_tarefas_por_categoria = True
                                        
                                                else:
                                                    sg.popup_error('Falha ao excluir a tarefa.', title='Erro', background_color=cor_clara, text_color=cor_escura)

                                                window_consultar_tarefas_por_categoria.close()
                                                window_excluir_por_categoria.close()
                                            else:
                                                sg.popup('Não há tarefas na categoria selecionada.', title='Sem Tarefas', background_color=cor_clara, text_color=cor_escura)
                                                stop_excluir_tarefa = True

                                    else:
                                        sg.popup('Escolha uma categoria antes de consultar.', title='Aviso', background_color=cor_clara, text_color=cor_escura)

                        window_excluir_por_categoria.close()
                        window["-Dados-"].update("Tarefa eliminada com sucesso!")


                    elif eventos_eliminar == 'Data de Vencimento':
                        window_eliminar.close()

                        layout_escolher_data = [
                            [sg.Text('Escolha a data:', size=(45, 1), expand_x=True, font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura)],
                            [sg.CalendarButton('Escolha a Data', target='-DATA-', font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)),
                            sg.InputText("", key='-DATA-', readonly=True, font=("Cooper Hewitt", 12))],
                            [sg.Button('Consultar', font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura))],
                            [sg.Button('Retornar ao Menu', font=("Cooper Hewitt", 14), button_color=(cor_clara, cor_escura))]
                        ]

                        window_escolher_data = sg.Window(title="Escolher Data de Vencimento", resizable=True, background_color=cor_clara, finalize=True, layout=layout_escolher_data)

                        stop_escolher_data = False

                        while not stop_escolher_data:
                            eventos_escolher_data, valores_escolher_data = window_escolher_data.read()

                            if eventos_escolher_data in (sg.WINDOW_CLOSED, 'Retornar ao Menu'):
                                stop_escolher_data = True
                                window_escolher_data.close()

                            elif eventos_escolher_data == 'Consultar':
                                data_selecionada_split = valores_escolher_data['-DATA-'].split()
                                data_selecionada = data_selecionada_split[0]
                                print(data_selecionada)
                                tarefas_filtradas = consultardatavencimento(data_selecionada, BD)

                                if not tarefas_filtradas:
                                    sg.popup('Não há tarefas com essa data de vencimento.', title='Aviso', background_color=cor_clara, text_color=cor_escura)
            
                                else:
                # Exibir tarefas filtradas
                                    tarefas_info = [f"{tarefa['id']}:{tarefa['titulo']}:{tarefa['descricao']}:{tarefa['data_vencimento']}:{tarefa['prioridade']}:{tarefa['categoria']}:{tarefa['concluida']}" for tarefa in tarefas_filtradas]

                                    layout_excluir_tarefa_por_data = [
                                        [sg.Listbox(values=tarefas_info, size=(80, 10), pad=((0, 0), (15, 10)), horizontal_scroll=True, key="-LIST-")],
                                        [sg.Button('Eliminar Tarefa', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12)),
                                        sg.Button('Cancelar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))]
                                    ]

                                    window_excluir_tarefa_por_data = sg.Window(title="Eliminar Tarefa pela Data de Vencimento", resizable=True, background_color=cor_clara).Layout(layout_excluir_tarefa_por_data)

                                    stop_excluir_tarefa_por_data = False

                                    while not stop_excluir_tarefa_por_data:
                                        eventos_excluir_tarefa_por_data, valores_excluir_tarefa_por_data = window_excluir_tarefa_por_data.read()

                                        if eventos_excluir_tarefa_por_data in (sg.WINDOW_CLOSED, 'Cancelar'):
                                            stop_excluir_tarefa_por_data = True

                                        elif eventos_excluir_tarefa_por_data == 'Eliminar Tarefa':
                                            tarefa_selecionada = valores_excluir_tarefa_por_data["-LIST-"][0].split(':')
                                            id_tarefa_selecionada = int(tarefa_selecionada[0])

                                            if eliminarTarefa(id_tarefa_selecionada, BD):
                                                sg.popup('Tarefa excluída com sucesso!', title='Sucesso', background_color=cor_clara, text_color=cor_escura)
                                                stop_consultar_tarefas_por_categoria = True
                                                window["-Dados-"].update("Tarefa eliminada com sucesso!")
                                        
                                            else:
                                                sg.popup_error('Falha ao excluir a tarefa.', title='Erro', background_color=cor_clara, text_color=cor_escura)


                                        window_excluir_tarefa_por_data.close()
                                        window_escolher_data.close()
                

                    elif eventos_eliminar=="Título":
                        window_eliminar.close()
                        resultados_e = []

                        layout_excluir_por_titulo = [
                            [sg.Text('Escolha o título para excluir tarefas:', size=(45, 1), expand_x=True, font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura)],
                            [sg.Combo(values=listatitulo(BD), key='-TITULO_EXCLUIR-', font=("Cooper Hewitt", 12), background_color=cor_escura, text_color=cor_clara)],
                            [sg.Button('Consultar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12)),
                            sg.Button('Cancelar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))],
                            [sg.Listbox(values=[], size=(80, 10), pad=((0, 0), (15, 10)), horizontal_scroll=True, key="-LIST_EXCLUIR-")]
                        ]

                        window_excluir_por_titulo = sg.Window(title="Excluir Tarefa por Título", resizable=True, background_color=cor_clara).Layout(layout_excluir_por_titulo)

                        stop_excluir_por_titulo = False       

                        while not stop_excluir_por_titulo:
                            eventos_excluir_por_titulo, valores_excluir_por_titulo = window_excluir_por_titulo.read()

                            if eventos_excluir_por_titulo in (sg.WINDOW_CLOSED, 'Cancelar'):
                                stop_excluir_por_titulo = True
                                window_excluir_por_titulo.close()

                            elif eventos_excluir_por_titulo == 'Consultar':
                                titulo_selecionado = valores_excluir_por_titulo['-TITULO_EXCLUIR-']
                # Filtrar tarefas pelo título
                                tarefas_filtradas = consultartitulo(titulo_selecionado, BD)
                # Exibir tarefas filtradas
                                tarefas_info = [f"{tarefa['id']}:{tarefa['titulo']}:{tarefa['descricao']}:{tarefa['data_vencimento']}:{tarefa['prioridade']}:{tarefa['categoria']}:{tarefa['concluida']}" for tarefa in tarefas_filtradas]

                                layout_excluir_tarefa_por_titulo = [
                                        [sg.Listbox(values=tarefas_info, size=(80, 10), pad=((0, 0), (15, 10)), horizontal_scroll=True, key="-LIST-")],
                                        [sg.Button('Eliminar Tarefa', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12)),
                                        sg.Button('Cancelar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))]
                                    ]

                                window_excluir_tarefa_por_titulo = sg.Window(title="Eliminar Tarefa pelo Título", resizable=True, background_color=cor_clara).Layout(layout_excluir_tarefa_por_titulo)

                                stop_excluir_tarefa_por_titulo = False

                                while not stop_excluir_tarefa_por_titulo:
                                    eventos_excluir_tarefa_por_titulo, valores_excluir_tarefa_por_titulo = window_excluir_tarefa_por_titulo.read()

                                    if eventos_excluir_tarefa_por_titulo in (sg.WINDOW_CLOSED, 'Cancelar'):
                                        stop_excluir_tarefa_por_titulo = True

                                    elif eventos_excluir_tarefa_por_titulo == 'Eliminar Tarefa':
                                        tarefa_selecionada = valores_excluir_tarefa_por_titulo["-LIST-"][0].split(':')
                                        id_tarefa_selecionada = int(tarefa_selecionada[0])

                                        if eliminarTarefa(id_tarefa_selecionada, BD):
                                            sg.popup('Tarefa excluída com sucesso!', title='Sucesso', background_color=cor_clara, text_color=cor_escura)
                                            stop_consultar_tarefas_por_categoria = True
                                            window["-Dados-"].update("Tarefa eliminada com sucesso!")
                                        
                                        else:
                                            sg.popup_error('Falha ao excluir a tarefa.', title='Erro', background_color=cor_clara, text_color=cor_escura)


                                    window_excluir_tarefa_por_titulo.close()
                                    window_excluir_por_titulo.close() 
        elif eventos == 'Relatórios':
            
            if BD == None:
                janelaErro ("Introduza primeiro uma base de dados!")
            
            elif Guardada == 0:
                janelaErro ("Guarde primeiro a base de dados!")

            else:
                layout_relatorio = [
                    [sg.Text ('Escolha o tipo de relatório:', size= (45,1), expand_x= True, font=("Cambria", 15, "bold"),background_color=cor_clara,text_color=cor_escura)],
                    [sg.Button ('Relatório Tabela', size=(15,1),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",12)),
                    sg.Button ('Relatório Escrito', size=(15,1),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",12)),
                    sg.Button ('Relatório Gráfico', size=(15,1),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",12)),
                    sg.Button ('Retornar ao Menu', size=(20,1),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",15))]     
                ]
            
                window_relatorio = sg.Window(title="Relatórios", resizable=True, background_color=cor_clara, finalize=True, layout=layout_relatorio)
                stop_relatorio = False

                while not stop_relatorio:
                    eventos_relatorio, valores_relatorio = window_relatorio.read()    

                    if eventos_relatorio in (sg.WINDOW_CLOSED, 'Retornar ao Menu'):
                        stop_relatorio = True
                        window_relatorio.close()

                    elif eventos_relatorio == 'Relatório Gráfico': 
                        plt.rcParams["axes.prop_cycle"] = plt.cycler(
                                                    color=[cor_mais_escura, cor_mais_clara, cor_complementar, cor_escura, cor_clara])
                        


                        def listarcategorias1(tarefas):
                            categorias = []

                            for tarefa in tarefas['tarefas']:
                                if 'categoria' in tarefa:
                                    categoria = tarefa['categoria'].lower().strip()
                                    categorias.append(categoria)

                            return categorias

                        categories = listarcategorias1(BD)
                        priorities = listaprioridades(BD)
                        due_dates = listardatas(BD)

                        plt.rcParams["axes.prop_cycle"] = plt.cycler(
                                                    color=[cor_mais_escura, cor_mais_clara, cor_complementar, cor_escura, cor_clara])

                        fig1, ax1 = plt.subplots()
                        category_counts = Counter(categories)
                        ax1.pie(category_counts.values(), labels=category_counts.keys(), autopct='%1.1f%%')
                        ax1.set_title("Task \n Categories")

                        fig2, ax2 = plt.subplots()
                        priority_counts = Counter(priorities)
                        ax2.bar(priority_counts.keys(), priority_counts.values(), color=[cor_mais_escura, cor_mais_clara, cor_complementar])
                        ax2.set_title("Task Priorities")
                        ax2.set_xlabel("Priority")
                        ax2.set_ylabel("Count")

                        dates = listardatas(BD)
                        dates.sort()
                        tamanho_figura = (5,4)
                        task_counts = list(range(1, len(dates) + 1))
                        fig3, ax3 = plt.subplots()
                        fig3.set_size_inches(tamanho_figura)
                        ax3.plot(dates, task_counts, marker='o')
                        ax3.set_title("Tasks Due Over Time")
                        ax3.set_xlabel("Due Date")
                        ax3.set_ylabel("Task Count")
                        ax3.tick_params(axis='both', which='major', labelsize=6)    


                        dates1 = listardatas(BD) 
                        months = [date.strftime("%B") for date in dates1] 
                        month_counts = Counter(months)
                        fig6, ax6 = plt.subplots()
                        fig6.set_size_inches(tamanho_figura)
                        ax6.bar(month_counts.keys(), month_counts.values(), color=[cor_mais_escura, cor_mais_clara, cor_complementar])
                        ax6.set_title("Distribuição pelos Meses do Ano")
                        ax6.set_xlabel("Mês")
                        ax6.set_ylabel("Número de Tarefas")
                        ax6.tick_params(axis='both', which='major', labelsize=10) 
                

                        concluidas, pendentes, atrasadas = calcular_progresso_tarefas(BD)
                        status_labels = ["Concluída", "Pendente", "Atrasada"]
                        status_values = [concluidas, pendentes, atrasadas]
                        fig7, ax7 = plt.subplots()
                        ax7.bar(status_labels, status_values, color=[cor_mais_escura, cor_mais_clara, cor_complementar])
                        ax7.set_title("Progresso das Tarefas")
                        ax7.set_xlabel("Status")
                        ax7.set_ylabel("Número de Tarefas")

                        root = tk.Tk()
                        root.title("Task Dashboard")
                        root.state('zoomed')

                        side_frame = tk.Frame(root, bg=cor_escura)
                        side_frame.pack(side="left", fill="y")

                        label = tk.Label(side_frame, text="Task \n Dashboard", bg=cor_escura, fg=cor_clara, font=20)
                        label.pack(pady=50, padx=5)

                        charts_frame = tk.Frame(root)
                        charts_frame.pack()

                        upper_frame = tk.Frame(charts_frame)
                        upper_frame.pack(fill="both", expand=True)

                        canvas6 = FigureCanvasTkAgg(fig6, upper_frame)
                        canvas6.draw()
                        canvas6.get_tk_widget().pack(side="left", fill="both", expand=True)

                        canvas3 = FigureCanvasTkAgg(fig3, upper_frame)
                        canvas3.draw()
                        canvas3.get_tk_widget().pack(side="left", fill="both", expand=True)

                        canvas1 = FigureCanvasTkAgg(fig1, upper_frame)
                        canvas1.draw()
                        canvas1.get_tk_widget().pack(side="left", fill="both", expand=True)

                        lower_frame = tk.Frame(charts_frame)
                        lower_frame.pack(fill="both", expand=True)

                        canvas2 = FigureCanvasTkAgg(fig2,lower_frame)
                        canvas2.draw()
                        canvas2.get_tk_widget().pack(side="left", fill="both", expand=True)

                        canvas7 = FigureCanvasTkAgg(fig7, lower_frame)
                        canvas7.draw()
                        canvas7.get_tk_widget().pack(side="left", fill="both", expand=True)


                    elif eventos_relatorio == 'Relatório Tabela':
                        df = pd.DataFrame(BD["tarefas"])

                        today_date = pd.to_datetime('today').strftime('%Y-%m-%d')

                        concluidas = df[(df['concluida']) & (df['data_vencimento'] < today_date)]
                        nao_concluidas = df[(~df['concluida']) & (df['data_vencimento'] < today_date)]
                        atrasadas = df[df['data_vencimento'] >= today_date]

                        # Remover duplicatas antes de concatenar
                        concluidas = concluidas.drop_duplicates()
                        nao_concluidas = nao_concluidas.drop_duplicates()
                        atrasadas = atrasadas.drop_duplicates()

                        # Organizar os DataFrames
                        todos = pd.concat([concluidas, nao_concluidas, atrasadas], ignore_index=True)

                        tarefas_rel = [
                            f"{row['id']}:{row['titulo']}:{row['descricao']}:{row['data_vencimento']}:{row['prioridade']}:{row['categoria']}:{'Concluída' if row['concluida'] else 'Atrasada' if row['data_vencimento'] < today_date else 'Não Concluída'}"
                            for _, row in todos.iterrows()
                        ]

                        datas = [tarefa.split(':') for tarefa in tarefas_rel]

                        layout_rel = [
                            [sg.Text('Relatório', font=('Cooper Hewitt', 20), justification='center', text_color=cor_escura, background_color=cor_clara)],
                            [sg.Table(values=datas, headings=["ID", "Título", "Descrição", "Data Vencimento", "Prioridade", "Categoria", "Status"], auto_size_columns=False, text_color=cor_escura, background_color='#FFF', justification='right', num_rows=min(25, len(datas)), enable_events=True, key='TABLE')],
                            [sg.Text(size=(40, 1), key='-INFO-', background_color=cor_clara)],
                            [sg.Button('Fechar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 15))]
                        ]

                        window_rel = sg.Window('Relatório', layout_rel, grab_anywhere=False, finalize=True, background_color=cor_clara)

                        stoprel1 = False

                        while not stoprel1:
                            eventrel, valuesrel = window_rel.read()
                            if eventrel == sg.WINDOW_CLOSED or eventrel == 'Fechar':
                                stoprel1 = True
                                window_rel.close()

                            elif eventrel == 'TABLE':
                                selected_row = valuesrel['TABLE'][0]

                                if selected_row is not None and selected_row < len(todos):
                                    layout_rel11 = [
                                        [sg.Text(f"Tarefa Selecionada:\n\nTítulo: {todos.iloc[selected_row]['titulo']}\n"
                                                f"Descrição: {todos.iloc[selected_row]['descricao']}\n"
                                                f"Data de Vencimento: {todos.iloc[selected_row]['data_vencimento']}\n"
                                                f"Prioridade: {todos.iloc[selected_row]['prioridade']}\n"
                                                f"Categoria: {todos.iloc[selected_row]['categoria']}\n"
                                                f"Concluída: {todos.iloc[selected_row]['concluida']}", text_color=cor_escura,
                                                background_color=cor_clara)],
                                        [sg.Button('Fechar', size=(10, 1), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura))]
                                    ]

                                    window_rel11 = sg.Window('Detalhes Tarefa', layout_rel11, grab_anywhere=False, finalize=True,
                                                            background_color=cor_clara)

                                    stop111 = False

                                    while not stop111:
                                        eventrel11, valuesrel11 = window_rel11.read()
                                        if eventrel11 == sg.WINDOW_CLOSED or eventrel11 == 'Fechar':
                                            stop111 = True
                                            window_rel11.close()

                    elif eventos_relatorio == "Relatório Escrito" :
                        exibir_relatorio_escrito_com_progresso( BD["tarefas"])

                window_relatorio.close()

        elif eventos == "Contagem":
            window["-Dados-"].update("A contar...")
            
            if BD == None:
                janelaErro ("Introduza primeiro uma base de dados!")
            
            elif Guardada == 0:
                janelaErro ("Guarde primeiro a base de dados!")

            else:
                categorias = listacategoria(BD)

                layout_contagem = [
                    [sg.Text ('Deseja contar tarefas por:', size= (45,1), expand_x= True, font=("Cambria", 15, "bold"),background_color=cor_clara,text_color=cor_escura)],
                    [sg.Button ('Total', size=(12,1),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",12)),sg.Button ('Prioridade', size=(12,1),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",12)),sg.Button ('Categoria', size=(12,1),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",12)),sg.Button ('Estado', size=(10,1),button_color=(cor_clara,cor_escura),font = ("Cooper Hewitt",12)),sg.Button ('Retornar ao Menu',font=("Cooper Hewitt", 14), button_color= (cor_clara,cor_escura))],     
                ]
            
                window_contagem = sg.Window(title="Contar tarefas", resizable=True, background_color=cor_clara, finalize=True, layout=layout_contagem)
                stop_contagem = False

                while not stop_contagem:
                    eventos_contagem, valores_contagem = window_contagem.read()    

                    if eventos_contagem in (sg.WINDOW_CLOSED, 'Retornar ao Menu'):
                        stop_contagem = True
                        window_contagem.close()
                    
                    elif eventos_contagem == 'Total':
                        res_c_total = len(BD['tarefas'])

                        layout_c_total = [[sg.Text(f"Existem {res_c_total} tarefas!", background_color=cor_clara, font=("Cooper Hewitt", 12), text_color=cor_escura)],
                                        [sg.Button("Ok", button_color=(cor_clara, cor_escura), font=('Cooper Hewitt', 12))]]

                        window_c_total = sg.Window(title="Resultado", resizable=True, background_color=cor_clara).Layout(layout_c_total)
                        stop_c_res_total = False

                        while not stop_c_res_total:
                            eventos_res_total, valores_res_total = window_c_total.read()
                            if eventos_res_total in [sg.WINDOW_CLOSED, 'Ok']:
                                stop_c_res_total = True
                                window_c_total.close()

                        
                        window["-Dados-"].update("Tarefas contadas com sucesso!")


                                    
                    elif eventos_contagem == 'Categoria': 
                        
                    

                        layout_contagem_categoria = [
                            [sg.Text('Categoria:', size=(14, 1), expand_x=True, font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura)],
                            [sg.Combo(values=listacategoria(BD), key="catc", font=("Cooper Hewitt", 12),background_color=cor_escura, text_color=cor_clara)],
                            [sg.Button('OK', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12)),
                            sg.Button('Sair', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))],
                        ]

                        window_contagem_categoria = sg.Window(title="Contar as tarefas por categoria", resizable=True, background_color=cor_clara).Layout(layout_contagem_categoria)
                        stop_c_cat = False

                        while not stop_c_cat:
                            eventos_contagem_cat, valores_contagem_cat = window_contagem_categoria.read()

                            if eventos_contagem_cat in [sg.WINDOW_CLOSED, 'Sair']:
                                stop_c_cat = True
                        
                            elif eventos_contagem_cat == 'OK':
                                categoria_escolhida = valores_contagem_cat['catc']
                                res_c_cat = contagem(BD, 'categoria', categoria_escolhida)

                                layout_c_cat = [[sg.Text(f"Existem {res_c_cat} tarefas!", background_color=cor_clara, font=("Cooper Hewitt", 12), text_color=cor_escura)],
                                                [sg.Button("Ok", button_color=(cor_clara, cor_escura), font=('Cooper Hewitt', 12))]]

                                window_c_cat = sg.Window(title="Resultado", resizable=True, background_color=cor_clara).Layout(layout_c_cat)
                                stop_c_res_cat = False

                                while not stop_c_res_cat:
                                    eventos_res_cat, valores_res_cat = window_c_cat.read()
                                    if eventos_res_cat in [sg.WINDOW_CLOSED, 'Ok']:
                                        stop_c_cat = True
                                        stop_c_res_cat = True
                                        window_c_cat.close()
                                        window_contagem_categoria.close()

                                
                                window["-Dados-"].update("Tarefas contadas com sucesso!")


                    elif eventos_contagem == 'Estado':    
                    

                        layout_contagem_estado = [
                            [sg.Text('Escolha o estado das tarefas:', size=(20, 1), font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura)],
                            [sg.Button('Concluídas', size=(10, 2), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)),
                            sg.Button('Não concluídas', size=(13, 2), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura))],
                            [sg.Button('Cancelar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))]
                        ]

                        window_contagem_estado = sg.Window(title="Contar as tarefas por estado", resizable=True, background_color=cor_clara).Layout(layout_contagem_estado)
                        stop_c_est = False

                        while not stop_c_est:
                            eventos_contagem_est, valores_contagem_est = window_contagem_estado.read()

                            if eventos_contagem_est in [sg.WINDOW_CLOSED, 'Cancelar']:
                                stop_c_est = True
                                window_contagem_estado.close()

                            elif eventos_contagem_est == 'Concluídas':

                                res_c_est = contagem(BD, 'concluida', True)

                                layout_c_est = [[sg.Text(f"Existem {res_c_est} tarefas!", background_color=cor_clara, font=("Cooper Hewitt", 12), text_color=cor_escura)],
                                                [sg.Button("Ok", button_color=(cor_clara, cor_escura), font=('Cooper Hewitt', 12))]]

                                window_c_est = sg.Window(title="Resultado", resizable=True, background_color=cor_clara).Layout(layout_c_est)
                                stop_c_res_est = False

                                while not stop_c_res_est:
                                    eventos_res_est, valores_res_est = window_c_est.read()
                                    if eventos_res_est in [sg.WINDOW_CLOSED, 'Ok']:
                                        stop_c_est = True
                                        stop_c_res_est = True
                                        window_c_est.close()
                                        window_contagem_estado.close()

                                
                                window["-Dados-"].update("Tarefas contadas com sucesso!")
                            
                            elif eventos_contagem_est == 'Não concluídas':
                                res_c_est = contagem(BD, 'concluida', False)

                                layout_c_est = [[sg.Text(f"Existem {res_c_est} tarefas!", background_color=cor_clara, font=("Cooper Hewitt", 12), text_color=cor_escura)],
                                                [sg.Button("Ok", button_color=(cor_clara, cor_escura), font=('Cooper Hewitt', 12))]]

                                window_c_est = sg.Window(title="Resultado", resizable=True, background_color=cor_clara).Layout(layout_c_est)
                                stop_c_res_est = False

                                while not stop_c_res_est:
                                    eventos_res_est, valores_res_est = window_c_est.read()
                                    if eventos_res_est in [sg.WINDOW_CLOSED, 'Ok']:
                                        stop_c_est = True
                                        stop_c_res_est = True
                                        window_c_est.close()
                                        window_contagem_estado.close()

                                
                                window["-Dados-"].update("Tarefas contadas com sucesso!")


                    
                    elif eventos_contagem == 'Prioridade': 
                    

                        layout_contagem_prioridade = [
                            [sg.Text('Escolha a prioridade:', size=(20, 1), font=("Cambria", 15, "bold"), background_color=cor_clara, text_color=cor_escura)],
                            [sg.Button('Baixa', size=(10, 2), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)),
                            sg.Button('Média', size=(10, 2), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)),
                            sg.Button('Alta', size=(10, 2), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura)),
                            sg.Button('Urgente', size=(10, 2), font=("Cooper Hewitt", 12), button_color=(cor_clara, cor_escura))],
                            [sg.Button('Cancelar', button_color=(cor_clara, cor_escura), font=("Cooper Hewitt", 12))]
                        ]

                        window_contagem_prioridade = sg.Window(title="Contar as tarefas por prioridade", resizable=True, background_color=cor_clara).Layout(layout_contagem_prioridade)
                        stop_c_pri = False

                        while not stop_c_pri:
                            eventos_contagem_pri, valores_contagem_pri = window_contagem_prioridade.read()

                            if eventos_contagem_pri in [sg.WINDOW_CLOSED, 'Cancelar']:
                                stop_c_pri = True

                            elif eventos_contagem_pri in ['Baixa', 'Média', 'Alta', 'Urgente']:
                                prioridade_escolhida = eventos_contagem_pri
                                window_contagem_prioridade.close()
                                res_c_pri = contagem(BD, 'prioridade', prioridade_escolhida)

                                layout_c_pri = [[sg.Text(f"Existem {res_c_pri} tarefas!", background_color=cor_clara, font=("Cooper Hewitt", 12), text_color=cor_escura)],
                                                [sg.Button("Ok", button_color=(cor_clara, cor_escura), font=('Cooper Hewitt', 12))]]

                                window_c_pri = sg.Window(title="Resultado", resizable=True, background_color=cor_clara).Layout(layout_c_pri)
                                stop_c_res_pri = False

                                while not stop_c_res_pri:
                                    eventos_res_pri, valores_res_pri = window_c_pri.read()
                                    if eventos_res_pri in [sg.WINDOW_CLOSED, 'Ok']:
                                        stop_c_pri = True
                                        stop_c_res_pri = True
                                        window_c_pri.close()

                                window["-Dados-"].update("Tarefas contadas com sucesso!")


        elif eventos == 'Help':
                        

            coluna = [

                [sg.Text("Task Master", font=("Cambria", 24, "bold"), justification="center", background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("Bem-vindo à aplicação Task Master! Aqui serás capaz de organizar e manusear todas as tuas tarefas! Vamos explicar-te todas as funções que esta aplicação te traz!", font=("Cambria", 14), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("\nCarregar BD", font=("Cambria", 16, "bold"), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("Nesta opção terás de carregar uma base de dados com todas as tarefas que tenhas para depois podermos usá-la no resto das opções!", font=("Cambria", 14), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("\nGravar BD", font=("Cambria", 16, "bold"), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("Utiliza esta opção para gravar a base de dados que carregaste. Isso é especialmente útil após efetuares alterações nas tarefas.", font=("Cambria", 14), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("\nAcrescentar dataset", font=("Cambria", 16, "bold"), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("Adiciona mais bases de dados àquelas que já introduziste na aplicação. Desta forma, podes expandir o teu conjunto de dados!", font=("Cambria", 14), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("\nInserir nova tarefa", font=("Cambria", 16, "bold"), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("Aqui, podes adicionar novas tarefas facilmente. Elas serão automaticamente integradas no dataset.", font=("Cambria", 14), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("\nConsultar tarefa", font=("Cambria", 16, "bold"), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("Efetua consultas específicas às tuas tarefas, utilizando critérios como prioridade, categoria, estado, data de vencimento e título!", font=("Cambria", 14), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("\nListagem", font=("Cambria", 16, "bold"), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("Visualiza e lista todas as tarefas com base em parâmetros específicos.", font=("Cambria", 14), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("\nAlterar tarefa", font=("Cambria", 16, "bold"), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("Realiza todas as alterações necessárias nas tuas tarefas nesta opção!", font=("Cambria", 14), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("\nEliminar tarefa", font=("Cambria", 16, "bold"), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("Elimina as tarefas que precisas de remover com facilidade.", font=("Cambria", 14), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("\nRelatórios", font=("Cambria", 16, "bold"), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("Explora um dashboard estatístico que apresenta gráficos que mostram o progresso das tuas tarefas.", font=("Cambria", 14), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("\nContagem", font=("Cambria", 16, "bold"), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("Conta o número total de tarefas ou o número delas com base em prioridade, categoria ou estado.", font=("Cambria", 14), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("\nSair", font=("Cambria", 16, "bold"), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("Fecha a aplicação. Não te esqueças de gravar o dataset após fazer alterações!", font=("Cambria", 14), background_color=cor_clara, text_color=cor_escura)],
                [sg.Text("\nObrigada por utilizares o Task Master!", font=("Cambria", 16), background_color=cor_clara, text_color=cor_escura)]
            ]

            layout_help = [[sg.Column(coluna, scrollable=True, vertical_scroll_only=True, size=(1300, 600), background_color=cor_clara)]]


            window_help = sg.Window(title="Help", resizable=True, background_color=cor_clara).Layout(layout_help)

            stop_help = False

            while not stop_help:
                eventos_help, valores_help = window_help.read()

                if eventos_help == sg.WINDOW_CLOSED:
                    stop_help = True
                    window_help.close()

#Interface linha de comandos

def interfacelinhacomandos():
    def exibir_help():
        print("\nComandos disponíveis:")
        print("+------------------------------+------------------------------------------+")
        print("|       Comando                |                 Descrição                |")
        print("+------------------------------+------------------------------------------+")
        print("|   1. Carregar Dataset        | Carregar uma base de dados               |")
        print("|   2. Guardar Dataset         | Gravar a base de dados que carregada     |")
        print("|   3. Número total de Tarefas | Número total de tarefas na base de dados |")
        print("|   4. Inserir Tarefa          | Inserir uma nova tarefa                  |")
        print("|   5. Consultar Tarefa        | Consultar uma tarefa na base de dados    |")
        print("|   6. Listar Tarefas          | Listar as tarefas das bases de dados     |")
        print("|   7. Alterar Informações     | Alterar informações duma tarefa          |")
        print("|   8. Remover Tarefas         | Elimina uma tarefa                       |")
        print("|   9. Help                    | Imprime esta mensagem de ajuda           |")
        print("|   0. Sair                    | Fechar a aplicação.                      |")
        print("+------------------------------+------------------------------------------+")





    def carregarBD():
        while True:
            dataset = input("Digite o nome do dataset (somente JSON) no seu diretório de trabalho: ").strip()

            if not dataset.lower().endswith('.json'):
                print("Erro: O arquivo não possui extensão .json. Tente novamente.")
                continue

            if not os.path.exists(dataset):
                print("Erro: Arquivo não encontrado. Tente novamente.")
                continue

            with open(dataset, encoding="utf-8") as f:
                info = json.load(f)

            return info, dataset



        
    def gravarBD(tarefas, nome_dataset=None):
        if tarefas is not None:
            nome = nome_dataset or input("Digite o nome do dataset para salvar: ")
            with open(nome, 'w', encoding='utf-8') as ficheiro:
                json.dump(tarefas, ficheiro, ensure_ascii=False, indent=2)
            print(f"Base de dados salva com sucesso em {nome}")
        else:
            print("Carregue uma base de dados primeiro.")

    def inserir_tarefa(tarefas):
        print("\n===== Inserir Nova Tarefa =====")
        titulo = input("Digite o título da nova tarefa: ")
        descricao = input("Digite a descrição da nova tarefa: ")
        # Obtendo uma data de vencimento válida
        while True:
            data_vencimento = input("Digite a data de vencimento da nova tarefa (no formato YYYY-MM-DD): ")
            try:
                datetime.strptime(data_vencimento, '%Y-%m-%d')
                break
            except ValueError:
                print("Formato de data inválido. Tente novamente.")

        # Obtendo uma prioridade válida
        prioridades_validas = ["Baixa", "Média", "Alta", "Urgente"]
        prioridade = input("Digite a prioridade da nova tarefa (Baixa, Média, Alta, Urgente): ").capitalize()
        while prioridade not in prioridades_validas:
            print("Prioridade inválida. Escolha entre Baixa, Média, Alta ou Urgente.")
            prioridade = input("Digite a prioridade da nova tarefa (Baixa, Média, Alta, Urgente): ").capitalize()

        categoria = input("Digite a categoria da nova tarefa: ")
        stop1 = False 
        # Obtendo o status de conclusão
        while not stop1:
            novo_estado_input = input("A tarefa está concluída? (Sim/Não): ").lower().strip()

            # Verificar se a entrada indica 'sim' ou 'não'
            if novo_estado_input == 'sim':
                concluida = True
                stop1 = True 
            elif novo_estado_input == 'não':
                concluida = False
                stop1 = True
            else:
                print("Por favor, digite 'Sim' ou 'Não'.")

        # Criando o dicionário representando a nova tarefa
        nova_tarefa = {
            "id": len(tarefas['tarefas']) + 1,
            "titulo": titulo,
            "descricao": descricao,
            "data_vencimento": data_vencimento,
            "prioridade": prioridade,
            "categoria": categoria,
            "concluida": concluida
        }

        # Adicionando a nova tarefa à lista de tarefas no seu conjunto de dados
        tarefas['tarefas'].append(nova_tarefa)
        print("Tarefa adicionada com sucesso.")

    def validar_formato_data(data_str):
        try:
            datetime.strptime(data_str, '%Y-%m-%d')
            return True
        except ValueError:
            return False

    def exibir_info_tarefa(tarefa):
        print(f"ID: {tarefa['id']}, Título: {tarefa['titulo']}, Descrição: {tarefa['descricao']}, \n "
            f"Data de Vencimento: {tarefa['data_vencimento']}, Prioridade: {tarefa['prioridade']}, \n "
            f"Categoria: {tarefa['categoria']}, Concluída: {tarefa['concluida']}")

    def exibir_resultados(resultados, criterio):
        if resultados:
            print(f"\nResultados encontrados ({criterio}):")
            for tarefa in resultados:
                if criterio == "Título":
                    print(f"ID: {tarefa['id']}, Título: {tarefa['titulo']}")
                elif criterio == "Prioridade":
                    print(f"ID: {tarefa['id']}, Título: {tarefa['titulo']}, Prioridade: {tarefa['prioridade']}")
                elif criterio == "Data de Vencimento":
                    print(f"ID: {tarefa['id']}, Título: {tarefa['titulo']}, Data de Vencimento: {tarefa['data_vencimento']}")
                elif criterio == "Categoria":
                    print(f"ID: {tarefa['id']}, Título: {tarefa['titulo']}, Categoria: {tarefa['categoria']}")
                else:
                    print(f"ID: {tarefa['id']}, Título: {tarefa['titulo']}, Descrição: {tarefa['descricao']}, \n "
                        f"Data de Vencimento: {tarefa['data_vencimento']}, Prioridade: {tarefa['prioridade']}, \n "
                        f"Categoria: {tarefa['categoria']}, Concluída: {tarefa['concluida']}")
        else:
            print(f"Não existe tarefa com esse/a '{criterio}'.")

    def consultar_tarefa(tarefas):
        print("\n===== Consultar Tarefa =====")
        print("Escolha o método de consulta:")
        print("1. Por Título")
        print("2. Por Data de Vencimento")
        print("3. Por Prioridade")
        print("4. Por Estado")
        print("5. Por Categoria")

        escolha_metodo = input("Digite o número correspondente ao método de consulta desejado: ")

        if escolha_metodo == "1":
            titulo = input("Digite o título da tarefa para consulta: ")
            resultados = [tarefa for tarefa in tarefas["tarefas"] if "titulo" in tarefa and tarefa["titulo"].lower() == titulo.lower()]
            exibir_resultados(resultados, "Título")
        elif escolha_metodo == "2":
            while True:
                datavencimento = input("Digite a data de vencimento para consulta (no formato YYYY-MM-DD): ")
                if validar_formato_data(datavencimento):
                    break
                else:
                    print("Formato de data inválido. Tente novamente.")
            resultados = [tarefa for tarefa in tarefas["tarefas"] if "data_vencimento" in tarefa and tarefa["data_vencimento"] == datavencimento]
            exibir_resultados(resultados, "Data de Vencimento")
        elif escolha_metodo == "3":
            prioridades_validas = ["Baixa", "Média", "Alta", "Urgente"]
            while True:
                prioridade = input("Digite a prioridade ('Baixa', 'Média', 'Alta', 'Urgente') para consulta: ").capitalize()
                if prioridade in prioridades_validas:
                    break
                else:
                    print("Prioridade inválida. Escolha entre Baixa, Média, Alta ou Urgente.")
            resultados = [tarefa for tarefa in tarefas["tarefas"] if "prioridade" in tarefa.keys() and tarefa["prioridade"] == prioridade]
            exibir_resultados(resultados, "Prioridade")
        elif escolha_metodo == "4":
            estado = input("Digite 'concluído' ou 'não concluído' para consulta: ")
            resultados = [tarefa for tarefa in tarefas["tarefas"] if "concluida" in tarefa.keys() and ((estado.lower() == "concluído" and tarefa["concluida"]) or (estado.lower() == "não concluído" and not tarefa["concluida"]))]
            exibir_resultados(resultados, "Estado")
        elif escolha_metodo == "5":
            categoria = input("Digite a categoria para consulta: ")
            resultados = [tarefa for tarefa in tarefas["tarefas"] if "categoria" in tarefa.keys() and tarefa["categoria"].lower() == categoria.lower()]
            exibir_resultados(resultados, "Categoria")
        else:
            print("Opção inválida. Tente novamente.")

        if resultados:
            id_disponiveis = [str(tarefa['id']) for tarefa in resultados]
            escolha_id = input(f"\nDigite o ID da tarefa que deseja exibir ({', '.join(id_disponiveis)}) (ou pressione Enter para sair): ")
            if escolha_id:
                tarefa_escolhida = next((tarefa for tarefa in resultados if str(tarefa['id']) == escolha_id), None)
                if tarefa_escolhida:
                    exibir_info_tarefa(tarefa_escolhida)
                else:
                    print(f"ID '{escolha_id}' não encontrado. Nenhuma tarefa exibida.")

    def consulta_tarefas(tarefas):
        print("\n===== Consultar Tarefas =====")
        print("Escolha a opção de consulta:")
        print("1. Listar todas as tarefas")
        print("2. Ordenar por Data de Vencimento")
        print("3. Ordenar por Prioridade")
        print("4. Ordenar por Categoria")
        print("0. Voltar ao Menu Principal")

        escolha_opcao = input("\nDigite o número correspondente à opção desejada: ")

        if escolha_opcao == "1":
            # Listar todas as tarefas
            exibir_resultados(tarefas["tarefas"], "Todas as Tarefas")
        elif escolha_opcao == "2":
            # Ordenar por Data de Vencimento
            tarefas_ordenadas = sorted(tarefas["tarefas"], key=lambda x: x.get("data_vencimento", ""))
            exibir_resultados(tarefas_ordenadas, "Ordenado por Data de Vencimento")
        elif escolha_opcao == "3":
            # Ordenar por Prioridade
            print("Escolha a ordem de classificação para Prioridade:")
            print("1. Urgente, Alta, Média, Baixa")
            print("2. Baixa, Média, Alta, Urgente")

            escolha_ordem_prioridade = input("\nDigite o número correspondente à ordem desejada para Prioridade: ")
            if escolha_ordem_prioridade == "1":
                prioridade_order = {"Urgente": 0, "Alta": 1, "Média": 2, "Baixa": 3}
            elif escolha_ordem_prioridade == "2":
                prioridade_order = {"Baixa": 0, "Média": 1, "Alta": 2, "Urgente": 3}
            else:
                print("Opção inválida. Utilizando a ordem padrão Urgente, Alta, Média, Baixa.")
                prioridade_order = {"Urgente": 0, "Alta": 1, "Média": 2, "Baixa": 3}

            tarefas_ordenadas = sorted(tarefas["tarefas"], key=lambda x: prioridade_order.get(x.get("prioridade", ""), 999))
            exibir_resultados(tarefas_ordenadas, "Ordenado por Prioridade")
        elif escolha_opcao == "4":
            # Ordenar por Categoria
            print("Escolha a ordem de classificação para a Categoria:")
            print("1. Crescente (A-Z)")
            print("2. Decrescente (Z-A)")

            escolha_ordem = input("\nDigite o número correspondente à ordem desejada: ")
            reverse_order = escolha_ordem == "2"

            tarefas_ordenadas = sorted(tarefas["tarefas"], key=lambda x: x.get("categoria", ""), reverse=reverse_order)
            exibir_resultados(tarefas_ordenadas, f"Ordenado por Categoria ({'Decrescente' if reverse_order else 'Crescente'})")
        elif escolha_opcao == "0":
            return
        else:
            print("Opção inválida. Tente novamente.")
        
        consulta_tarefas(tarefas)

    def alterar_informacoes(tarefas):
        while True:
            print("\n===== Alterar Informações =====")
            
            # Mostrar todas as tarefas para que o usuário escolha qual alterar
            exibir_resultados(tarefas["tarefas"], "Todas as Tarefas")
            
            # Obter o ID da tarefa a ser alterada
            while True:
                id_tarefa = input("\nDigite o ID da tarefa que deseja alterar (ou pressione Enter para sair): ")
                if not id_tarefa:
                    return  # Se pressionar Enter, sai da função
                if id_tarefa.isdigit():
                    id_tarefa = int(id_tarefa)
                    if any(tarefa['id'] == id_tarefa for tarefa in tarefas["tarefas"]):
                        break
                    else:
                        print(f"ID '{id_tarefa}' não encontrado. Tente novamente.")
                else:
                    print("ID inválido. Digite um número inteiro válido.")

            # Obter a tarefa correspondente ao ID
            tarefa_alterar = next(tarefa for tarefa in tarefas["tarefas"] if tarefa['id'] == id_tarefa)

            while True:
                print("\nEscolha o que deseja alterar:")
                print("1. Título")
                print("2. Descrição")
                print("3. Data de Vencimento")
                print("4. Prioridade")
                print("5. Categoria")
                print("6. Estado (Concluída/Não Concluída)")
                print("0. Finalizar Alterações")

                escolha_opcao = input("\nDigite o número correspondente à opção desejada: ")

                if escolha_opcao == "1":
                    novo_titulo = input("Digite o novo título: ")
                    tarefa_alterar["titulo"] = novo_titulo
                elif escolha_opcao == "2":
                    nova_descricao = input("Digite a nova descrição: ")
                    tarefa_alterar["descricao"] = nova_descricao
                elif escolha_opcao == "3":
                    while True:
                        nova_data_vencimento = input("Digite a nova data de vencimento (no formato YYYY-MM-DD): ")
                        if validar_formato_data(nova_data_vencimento):
                            tarefa_alterar["data_vencimento"] = nova_data_vencimento
                            break
                        else:
                            print("Formato de data inválido. Tente novamente.")
                elif escolha_opcao == "4":
                    prioridades_validas = ["Baixa", "Média", "Alta", "Urgente"]
                    nova_prioridade = input("Digite a nova prioridade (Baixa, Média, Alta, Urgente): ").capitalize()
                    while nova_prioridade not in prioridades_validas:
                        print("Prioridade inválida. Escolha entre Baixa, Média, Alta ou Urgente.")
                        nova_prioridade = input("Digite a nova prioridade (Baixa, Média, Alta, Urgente): ").capitalize()
                    tarefa_alterar["prioridade"] = nova_prioridade
                elif escolha_opcao == "5":
                    nova_categoria = input("Digite a nova categoria: ")
                    tarefa_alterar["categoria"] = nova_categoria
                elif escolha_opcao == "6":
                    while True:
                        novo_estado_input = input("A tarefa está concluída? (Sim/Não): ").lower()

                        if novo_estado_input == 'sim':
                            novo_estado = True
                            break
        
                        elif novo_estado_input == 'não':
                            novo_estado = False
                            break
                        else:
                            print("Por favor, digite 'Sim' ou 'Não'.")

                    tarefa_alterar["concluida"] = novo_estado

                elif escolha_opcao == "0":
                    break  # Finalizar o loop interno e voltar para o externo
                else:
                    print("Opção inválida. Tente novamente.")

                print("Informações alteradas com sucesso.")
                exibir_info_tarefa(tarefa_alterar)

    def remover_tarefa(tarefas):
        print("\n===== Remover Tarefa =====")
        exibir_resultados(tarefas["tarefas"], "Todas as Tarefas")
        id_tarefa = input("Digite o ID da tarefa que deseja remover (ou pressione Enter para sair): ")

        if id_tarefa.isdigit():
            id_tarefa = int(id_tarefa)
            tarefa_encontrada = next((tarefa for tarefa in tarefas['tarefas'] if tarefa['id'] == id_tarefa), None)

            if tarefa_encontrada:
                confirmacao = input(f"Tem certeza de que deseja remover a tarefa '{tarefa_encontrada['titulo']}'? (Sim/Não): ").lower().strip()

                if confirmacao == 'sim':
                    tarefas['tarefas'].remove(tarefa_encontrada)
                    print(f"Tarefa '{tarefa_encontrada['titulo']}' removida com sucesso.")

                    # Atualizar IDs das outras tarefas
                    for i, tarefa in enumerate(tarefas['tarefas']):
                        tarefa['id'] = i + 1

                    print("IDs das outras tarefas foram atualizados.")
                else:
                    print("Remoção cancelada.")
            else:
                print(f"ID '{id_tarefa}' não encontrado. Nenhuma tarefa removida.")
        elif not id_tarefa:
            print("Operação de remoção cancelada (nenhum ID fornecido).")
        else:
            print("ID inválido. Digite um número inteiro válido.")


    def menu_principal():
        tarefas = None 
        nome_dataset = None
        carregada_e_guardada = False 

        while True:
            print("\n===== Menu Principal =====")
            print("1. Carregar Dataset")
            print("2. Guardar Dataset")
            print("3. Número total de Tarefas")
            print("4. Inserir Tarefa")
            print("5. Consultar Tarefa")
            print("6. Listar Tarefas")
            print("7. Alterar Informações")
            print("8. Remover Tarefa")
            print("9. Help")
            print("0. Sair")

            escolha = input("\nEscolha uma opção: ")

            if escolha == "1":
                tarefas, nome_dataset= carregarBD()
                if tarefas:
                    print("Base de dados carregada com sucesso.")
                else :
                    carregada_e_guardada = False 
            elif escolha == "2":
                gravarBD(tarefas, nome_dataset)
                carregada_e_guardada = True
            elif escolha == "3":
                if carregada_e_guardada:
                    total_tarefas = len(tarefas['tarefas'])
                    print(f"O número total de tarefas é: {total_tarefas}")
                else:
                    print("Carregue e salve uma base de dados primeiro.")
            elif escolha == "4":
                if carregada_e_guardada:
                    inserir_tarefa(tarefas)
                else:
                    print("Carregue e salve uma base de dados primeiro.")
            elif escolha == "5":
                if carregada_e_guardada:
                    consultar_tarefa(tarefas)
                else : 
                    print("Carregue e salve uma base de dados primeiro.")    
            elif escolha == "6":
                if carregada_e_guardada:
                    consulta_tarefas(tarefas)
                else:
                    print("Carregue e salve uma base de dados primeiro.")    
            elif escolha == "7":
                if carregada_e_guardada:
                    alterar_informacoes(tarefas)
                else:
                    print("Carregue e salve uma base de dados primeiro.")  
            elif escolha == "8":
                if carregada_e_guardada:
                    remover_tarefa(tarefas)
                else:
                    print("Carregue e salve uma base de dados primeiro.")
            elif escolha == "9":
                exibir_help()
            elif escolha == "0":
                break
            else:
                print("Opção inválida. Tente novamente.")

    if __name__ == "__main__":
        menu_principal()


layout_escolherinterface = [
    [sg.Push(background_color=cor_clara),
     sg.Button('Interface Gráfica', size=(30, 2), font=("Cooper Hewitt", 14), button_color=(cor_clara, cor_escura),
               tooltip='Clique para escolher Interface Gráfica'),
     sg.Button("Interface Linha de Comandos (CLI)", size=(30, 2), font=("Cooper Hewitt", 14), button_color=(cor_clara, cor_escura),
               tooltip='Clique para escolher CLI'),
     sg.Push(background_color=cor_clara)]
]

cabecalhointerfaces = [
    [sg.Text("Escolha uma Interface", size=(35, 1), expand_x=True, justification="center", font=("Cambria", 32, "bold"),
             background_color=cor_clara, text_color=cor_escura)],
    [sg.Text("MENU", size=(35, 1), expand_x=True, justification="center", font=("Cambria", 20),
             background_color=cor_clara, text_color=cor_escura)],
    [sg.Push(background_color=cor_clara),
     sg.Text('  ' * 205, justification="center", background_color=cor_escura, pad=(0, 15)),
     sg.Push(background_color=cor_clara)]
]

layoutfinal = [
    cabecalhointerfaces,
    layout_escolherinterface,
    [sg.Push( background_color=cor_clara),sg.Text('  '*205, justification= "center", background_color=cor_escura, pad=(0, 15)), sg.Push( background_color=cor_clara)],
    [sg.Button("Sair", size=(20, 1), font=("Cooper Hewitt", 18), button_color=(cor_escura, cor_clara),
               tooltip='Clique para sair da aplicação')]
  
]


window_escolherinterface = sg.Window(title= "Escolha uma interface", resizable=True, background_color=cor_clara).Layout(layoutfinal)
condicao = True
while condicao :
    eventosinterfaces, valoresinterfaces = window_escolherinterface.read()

    if eventosinterfaces==sg.WIN_CLOSED or eventosinterfaces == "Sair" :
        condicao = False
    elif eventosinterfaces == 'Interface Gráfica' :
        interfacegrafica()
    elif eventosinterfaces == "Interface Linha de Comandos (CLI)" :
        interfacelinhacomandos()


